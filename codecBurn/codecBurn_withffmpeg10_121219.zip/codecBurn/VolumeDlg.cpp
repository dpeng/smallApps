#include "stdafx.h"
#include "codecBurn.h"
#include "VolumeDlg.h"
#include "codecBurnDlg.h"

IMPLEMENT_DYNAMIC(CVolumeDlg, CDialog)

CVolumeDlg::CVolumeDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CVolumeDlg::IDD, pParent)
{

}

CVolumeDlg::~CVolumeDlg()
{
#ifdef SYSTEM_VOLUME
	amdUninitialize();
#endif
}

void CVolumeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_BTNVOLUME, m_btnMyVolume);
	DDX_Control(pDX, IDC_SOFTVOLUMESLIDER, m_softVolume);
#ifdef SYSTEM_VOLUME
	DDX_Control(pDX, IDC_SYSTEMVOLUMESLIDER, m_systemVolume);
#endif
}


BEGIN_MESSAGE_MAP(CVolumeDlg, CDialog)
	ON_BN_CLICKED(IDC_BTNVOLUME, /*&CVolumeDlg::*/OnBnClickedBtnvolume)
	ON_WM_CTLCOLOR()
	ON_WM_VSCROLL()
END_MESSAGE_MAP()

void CVolumeDlg::OnBnClickedBtnvolume()
{
	m_bVolumeChange = TRUE;
	if (!m_bVolume)
	{
		m_btnMyVolume.SetSkin(IDB_VOLUMEONOVER, IDB_VOLUMEONNORMAL, IDB_VOLUMEONDOWN, 0, 0, 0, 0, 0, 0);
		m_btnMyVolume.SizeToContent();
		VN_PLAY_PlaySound(0);
	}
	else
	{
		m_btnMyVolume.SetSkin(IDB_VOLUMEOFFOVER, IDB_VOLUMEOFFNORMAL, IDB_VOLUMEOFFDOWN, 0, 0, 0, 0, 0, 0);
		m_btnMyVolume.SizeToContent();
		VN_PLAY_StopSound();
	}
	m_bVolume = !m_bVolume;
}

HBRUSH CVolumeDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);

	pDC->SetBkMode(TRANSPARENT);
	return m_Brush;
	return hbr;
}

BOOL CVolumeDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	m_bVolume = TRUE;
	m_btnMyVolume.SetSkin(IDB_VOLUMEONOVER, IDB_VOLUMEONNORMAL, IDB_VOLUMEONDOWN, 0, 0, 0, 0, 0, 0);
	m_btnMyVolume.SizeToContent();

	m_Brush.CreateSolidBrush(SYSTEM_BACKCOLOR);
	m_softVolume.SetRange(0,99);//max:0xffff
	m_softVolume.SetTicFreq(10); 
	m_bVolumeChange = FALSE;

#ifdef SYSTEM_VOLUME
	m_systemVolume.SetRange(0,99);//max:0xffff
	m_systemVolume.SetTicFreq(10); 
	if (amdInitialize())
	{
		// get the Control ID and the names
		amdGetMasterVolumeControl();

		if (amdGetMasterVolumeValue(m_dwVal))
			amdGetMasterMuteControl();

		LONG lVal;
		if (amdGetMasterMuteValue(lVal))
			m_bMute = lVal;

		UpdateData(FALSE);
	}
	m_systemVolume.SetPos(m_dwVal*100/0xffff);
#endif
	return TRUE;
}

void CVolumeDlg::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	int volume = 0;
	switch(GetWindowLong(pScrollBar->m_hWnd, GWL_ID))
	{
	case IDC_SOFTVOLUMESLIDER:
		volume = MAX_VOLUME - (m_softVolume.GetPos())*MAX_VOLUME/100;
		VN_PLAY_SetVolume(0,volume) ;
		break;
#ifdef SYSTEM_VOLUME
	case IDC_SYSTEMVOLUMESLIDER:
		volume = MAX_VOLUME - (m_systemVolume.GetPos())*MAX_VOLUME/100;
		amdSetMasterVolumeValue(volume);
		break;
#endif
	default:
		break;
	}
	CDialog::OnVScroll(nSBCode, nPos, pScrollBar);
}

#ifdef SYSTEM_VOLUME
BOOL CVolumeDlg::amdInitialize()
{
	// get the number of mixer devices present in the system
	m_nNumMixers = ::mixerGetNumDevs();

	m_hMixer = NULL;
	::ZeroMemory(&m_mxcaps, sizeof(MIXERCAPS));

	// open the first mixer
	// A "mapper" for audio mixer devices does not currently exist.
	if (m_nNumMixers != 0)
	{
		if (::mixerOpen(&m_hMixer,
			0,
			(DWORD)this->GetSafeHwnd(),
			NULL,
			MIXER_OBJECTF_MIXER | CALLBACK_WINDOW)
			!= MMSYSERR_NOERROR)
			return FALSE;

		if (::mixerGetDevCaps((UINT)m_hMixer, &m_mxcaps, sizeof(MIXERCAPS))
			!= MMSYSERR_NOERROR)
			return FALSE;
	}

	return TRUE;
}

BOOL CVolumeDlg::amdUninitialize()
{
	BOOL bSucc = TRUE;

	if (m_hMixer != NULL)
	{
		bSucc = ::mixerClose(m_hMixer) == MMSYSERR_NOERROR;
		m_hMixer = NULL;
	}

	return bSucc;
}

BOOL CVolumeDlg::amdGetMasterVolumeControl()
{
	if (m_hMixer == NULL)
		return FALSE;

	// get dwLineID
	MIXERLINE mxl;
	mxl.cbStruct = sizeof(MIXERLINE);
	mxl.dwComponentType = MIXERLINE_COMPONENTTYPE_DST_SPEAKERS;
	if (::mixerGetLineInfo((HMIXEROBJ)m_hMixer,
		&mxl,
		MIXER_OBJECTF_HMIXER |
		MIXER_GETLINEINFOF_COMPONENTTYPE)
		!= MMSYSERR_NOERROR)
		return FALSE;

	// get dwControlID
	MIXERCONTROL mxc;
	MIXERLINECONTROLS mxlc;
	mxlc.cbStruct = sizeof(MIXERLINECONTROLS);
	mxlc.dwLineID = mxl.dwLineID;
	mxlc.dwControlType = MIXERCONTROL_CONTROLTYPE_VOLUME; //��?��?
	mxlc.cControls = 1;
	mxlc.cbmxctrl = sizeof(MIXERCONTROL);
	mxlc.pamxctrl = &mxc;
	if (::mixerGetLineControls((HMIXEROBJ)m_hMixer,
		&mxlc,
		MIXER_OBJECTF_HMIXER |
		MIXER_GETLINECONTROLSF_ONEBYTYPE)
		!= MMSYSERR_NOERROR)
		return FALSE;

	// record dwControlID
	m_dwMinimum = mxc.Bounds.dwMinimum;
	m_dwMaximum = mxc.Bounds.dwMaximum;
	m_dwVolumeControlID = mxc.dwControlID;

	return TRUE;
}

BOOL CVolumeDlg::amdGetMasterMuteControl()
{
	if (m_hMixer == NULL)
		return FALSE;

	// get dwLineID
	MIXERLINE mxl;
	mxl.cbStruct = sizeof(MIXERLINE);
	mxl.dwComponentType = MIXERLINE_COMPONENTTYPE_DST_SPEAKERS;
	if (::mixerGetLineInfo((HMIXEROBJ)m_hMixer,
		&mxl,
		MIXER_OBJECTF_HMIXER |
		MIXER_GETLINEINFOF_COMPONENTTYPE)
		!= MMSYSERR_NOERROR)
		return FALSE;

	// get dwControlID
	MIXERCONTROL mxc;
	MIXERLINECONTROLS mxlc;
	mxlc.cbStruct = sizeof(MIXERLINECONTROLS);
	mxlc.dwLineID = mxl.dwLineID;
	mxlc.dwControlType = MIXERCONTROL_CONTROLTYPE_MUTE; //?2��?
	mxlc.cControls = 1;
	mxlc.cbmxctrl = sizeof(MIXERCONTROL);
	mxlc.pamxctrl = &mxc;
	if (::mixerGetLineControls((HMIXEROBJ)m_hMixer,
		&mxlc,
		MIXER_OBJECTF_HMIXER |
		MIXER_GETLINECONTROLSF_ONEBYTYPE)
		!= MMSYSERR_NOERROR)
		return FALSE;

	// record dwControlID
	m_dwMuteControlID = mxc.dwControlID;

	return TRUE;
}

BOOL CVolumeDlg::amdGetMasterVolumeValue(DWORD &dwVal) const
{
	if (m_hMixer == NULL)
		return FALSE;

	MIXERCONTROLDETAILS_UNSIGNED mxcdVolume;
	MIXERCONTROLDETAILS mxcd;
	mxcd.cbStruct = sizeof(MIXERCONTROLDETAILS);
	mxcd.dwControlID = m_dwVolumeControlID;
	mxcd.cChannels = 1;
	mxcd.cMultipleItems = 0;
	mxcd.cbDetails = sizeof(MIXERCONTROLDETAILS_UNSIGNED);
	mxcd.paDetails = &mxcdVolume;
	if (::mixerGetControlDetails((HMIXEROBJ)m_hMixer,
		&mxcd,
		MIXER_OBJECTF_HMIXER |
		MIXER_GETCONTROLDETAILSF_VALUE)
		!= MMSYSERR_NOERROR)
		return FALSE;

	dwVal = mxcdVolume.dwValue;

	return TRUE;
}

BOOL CVolumeDlg::amdSetMasterVolumeValue(DWORD dwVal) const
{
	if (m_hMixer == NULL)
		return FALSE;

	MIXERCONTROLDETAILS_UNSIGNED mxcdVolume = { dwVal };
	MIXERCONTROLDETAILS mxcd;
	mxcd.cbStruct = sizeof(MIXERCONTROLDETAILS);
	mxcd.dwControlID = m_dwVolumeControlID;
	mxcd.cChannels = 1;
	mxcd.cMultipleItems = 0;
	mxcd.cbDetails = sizeof(MIXERCONTROLDETAILS_UNSIGNED);
	mxcd.paDetails = &mxcdVolume;
	if (::mixerSetControlDetails((HMIXEROBJ)m_hMixer,
		&mxcd,
		MIXER_OBJECTF_HMIXER |
		MIXER_SETCONTROLDETAILSF_VALUE)
		!= MMSYSERR_NOERROR)
		return FALSE;

	return TRUE;
}

BOOL CVolumeDlg::amdGetMasterMuteValue(LONG &lVal) const
{
	if (m_hMixer == NULL)
		return FALSE;

	MIXERCONTROLDETAILS_BOOLEAN mxcdMute;
	MIXERCONTROLDETAILS mxcd;
	mxcd.cbStruct = sizeof(MIXERCONTROLDETAILS);
	mxcd.dwControlID = m_dwMuteControlID;
	mxcd.cChannels = 1;
	mxcd.cMultipleItems = 0;
	mxcd.cbDetails = sizeof(MIXERCONTROLDETAILS_BOOLEAN);
	mxcd.paDetails = &mxcdMute;
	if (::mixerGetControlDetails((HMIXEROBJ)m_hMixer,
		&mxcd,
		MIXER_OBJECTF_HMIXER |
		MIXER_GETCONTROLDETAILSF_VALUE)
		!= MMSYSERR_NOERROR)
		return FALSE;

	lVal = mxcdMute.fValue;

	return TRUE;
}

BOOL CVolumeDlg::amdSetMasterMuteValue(LONG lVal) const
{
	if (m_hMixer == NULL)
		return FALSE;

	MIXERCONTROLDETAILS_BOOLEAN mxcdMute = { lVal };
	MIXERCONTROLDETAILS mxcd;
	mxcd.cbStruct = sizeof(MIXERCONTROLDETAILS);
	mxcd.dwControlID = m_dwMuteControlID;
	mxcd.cChannels = 1;
	mxcd.cMultipleItems = 0;
	mxcd.cbDetails = sizeof(MIXERCONTROLDETAILS_BOOLEAN);
	mxcd.paDetails = &mxcdMute;
	if (::mixerSetControlDetails((HMIXEROBJ)m_hMixer,
		&mxcd,
		MIXER_OBJECTF_HMIXER |
		MIXER_SETCONTROLDETAILSF_VALUE)
		!= MMSYSERR_NOERROR)
		return FALSE;

	return TRUE;
}
#endif