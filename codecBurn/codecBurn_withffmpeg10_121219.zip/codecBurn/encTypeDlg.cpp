// EncType.cpp : implementation file
//

#include "stdafx.h"
#include "codecBurn.h"
#include "encTypeDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CEncTypeDlg::CEncTypeDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEncTypeDlg::IDD, pParent)
{
}


void CEncTypeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_ENCODE_TO_BTN, m_btnEncTo);
	DDX_Control(pDX, IDC_ENCODE_FROM_BTN, m_btnEncFrom);
	DDX_Control(pDX, IDC_CLOSEENCTYPEDLG, m_btnClose);
	DDX_Control(pDX, IDCANCEL, m_btnCancel);
	DDX_Control(pDX, IDOK, m_btnOk);
}


BEGIN_MESSAGE_MAP(CEncTypeDlg, CDialog)
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_CLOSEENCTYPEDLG, OnCloseenctypedlg)
	ON_BN_CLICKED(IDC_ENCODE_FROM_BTN, OnEncodeFromBtn)
	ON_BN_CLICKED(IDC_ENCODE_TO_BTN, OnEncodeToBtn)
END_MESSAGE_MAP()

BOOL CEncTypeDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_encType = MPEG1_ENCODE;
	m_Brush.CreateSolidBrush(SYSTEM_BACKCOLOR);
	CreateSkin();
	m_strFromFile = _T("");
	m_strToFile = _T("");
	m_strTmpToFile = _T("");
	m_bAviFile = FALSE;
	return TRUE;
}

HBRUSH CEncTypeDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	pDC->SetBkMode(TRANSPARENT);
	return m_Brush;
	return hbr;
}


void CEncTypeDlg::CreateSkin()
{
	m_titleBar.Create(CRect(0,0,520,25),this,
		IDB_COMONTITLE,IDB_COMONTITLE,
		IDB_COMONTITLE,IDB_COMONTITLE);
	m_titleBar.SetLabel("Video Converter");

	m_btnEncTo.SetSkin(IDB_ENCBTNNORMAL, IDB_ENCBTNDOWN, IDB_ENCBTNOVER, 0, 0, 0, 0, 0, 0);
	m_btnEncTo.SetTextColor(SYSTEM_BTNCOLOR);
	m_btnEncTo.SizeToContent();
	
	m_btnEncFrom.SetSkin(IDB_ENCBTNNORMAL, IDB_ENCBTNDOWN, IDB_ENCBTNOVER, 0, 0, 0, 0, 0, 0);
	m_btnEncFrom.SetTextColor(SYSTEM_BTNCOLOR);
	m_btnEncFrom.SizeToContent();
	
	m_btnClose.SetSkin(IDB_EXITNORMAL, IDB_EXITDOWN, IDB_EXITOVER, 0, 0, 0, 0, 0, 0);
	m_btnClose.SetTextColor(SYSTEM_BTNCOLOR);
	m_btnClose.SizeToContent();

    m_btnOk.SetSkin(IDB_COMONBTNNORMAL, IDB_COMONBTNDOWN, IDB_COMONBTNOVER, 0, 0, 0, 0, 0, 0);
	m_btnOk.SetTextColor(SYSTEM_BTNCOLOR);
	m_btnOk.SizeToContent();
	
    m_btnCancel.SetSkin(IDB_COMONBTNNORMAL, IDB_COMONBTNDOWN, IDB_COMONBTNOVER, 0, 0, 0, 0, 0, 0);
	m_btnCancel.SetTextColor(SYSTEM_BTNCOLOR);
	m_btnCancel.SizeToContent();
}

void CEncTypeDlg::OnCloseenctypedlg() 
{
	DeleteObject(m_Brush);
	CDialog::OnCancel();
}

void CEncTypeDlg::OnEncodeFromBtn() 
{
	CFileDialog FileChooser(TRUE, 
		NULL,
		NULL, 
		OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		"DAV Files (*.dav)|*.dav|AVI Files (*.avi)|*.avi||");

	if (FileChooser.DoModal()==IDOK)
	{
		m_strFromFile = FileChooser.GetPathName();
		CString TmpStr = CConfigurationSingleton::instance()->m_util.getFileSuffix(m_strFromFile);
		if ( (TmpStr != "dav") && (TmpStr != "DAV") &&
			(TmpStr != "avi") && (TmpStr != "AVI") )
		{
			TmpStr.Format(_T("%s\n is not support,Please choose supported file format!"),m_strFromFile);
			MessageBox(TmpStr);
			return;
		}
		if ((TmpStr == "avi") || (TmpStr == "AVI"))
		{
			m_bAviFile = TRUE;
		}
		else
		{
			m_bAviFile = FALSE;
		}
		GetDlgItem(IDC_ENCODE_FROM)->SetWindowText(m_strFromFile);
		TCHAR buf[MAX_PATH] = {0};
		DWORD length = m_strFromFile.GetLength();
		strcpy(buf, m_strFromFile.GetBuffer(0));
		if (length <= 0)
			return;
		--length;
		for (; length>0; --length)
			if (buf[length] == '.')
			{
				buf[length] = 0;
				break;
			}
			
		length = strlen(buf);
		for (; length>0; --length)
			if (buf[length] == '/' || buf[length] == '\\')
			{
				break;
			}

		CString tmpToFileName = _T("");
		tmpToFileName.Format("%s%s",CConfigurationSingleton::instance()->m_strVideoName, &buf[length]);
		GetDlgItem(IDC_ENCODE_TO)->SetWindowText(tmpToFileName);
		tmpToFileName = _T("");
		tmpToFileName.Format("%s", &buf[length+1]);
		m_strTmpToFile = tmpToFileName;
	}
}

void CEncTypeDlg::OnEncodeToBtn() 
{
	CFileDialog FileChooser(FALSE, 
		CConfigurationSingleton::instance()->m_strVideoName,
		m_strTmpToFile,
		OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		"MPEG4 Files (*.mp4)|*.mp4|AVI Files (*.avi)|*.avi||");
	FileChooser.m_ofn.lpstrInitialDir = CConfigurationSingleton::instance()->m_strVideoName;

	if (FileChooser.DoModal()==IDOK)
	{
		m_strToFile = FileChooser.GetPathName();
		CString fileSuffix = CConfigurationSingleton::instance()->m_util.getFileSuffix(m_strToFile);
		if ( (fileSuffix != "mp4") && (fileSuffix != "MP4") &&
			 (fileSuffix != "avi") && (fileSuffix != "AVI") &&
			 (fileSuffix != "peg") && (fileSuffix != "PEG"))
		{
			fileSuffix.Format("%s\n is not support,Please choose supported file format!",m_strToFile);
			MessageBox(fileSuffix);
			return;
		}
		GetDlgItem(IDC_ENCODE_TO)->SetWindowText(m_strToFile);
		if ((fileSuffix == "mp4") || (fileSuffix == "MP4"))
		{
			m_encType = MPEG4_ENCODE;
		} 
		else if ((fileSuffix == "peg") || (fileSuffix == "PEG"))
		{
			m_encType = MPEG1_ENCODE;
		} 
		else if ((fileSuffix == "avi") || (fileSuffix == "AVI"))
		{
			m_encType = AVI_ENCODE;
		}
		else
		{
			m_encType = NULL_ENCODE;
		}
	}
}

void CEncTypeDlg::OnOK() 
{
	if ((m_strFromFile.GetLength() < 5) || (m_strToFile.GetLength() < 5))
	{
		AfxMessageBox("Parse Input/OutPut FileName error");
		return;
	}

	if (m_bAviFile && (m_encType == AVI_ENCODE))
	{
		MessageBox("Source file is already AVI format!");
		return;
	}
	CDialog::OnOK();
}

void CEncTypeDlg::OnCancel() 
{
	CDialog::OnCancel();
}
