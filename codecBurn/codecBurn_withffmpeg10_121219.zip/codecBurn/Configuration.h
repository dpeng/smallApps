#if !defined(_CONFIGURATION_H__)
#define _CONFIGURATION_H__

#if _MSC_VER > 1000
#pragma once
#endif

#include "xskinbutton.h"
#include "titleBar.h"
#include "Util.h"
#include "afxwin.h"
#include "Singleton.h"

class CConfiguration : public CDialog
{
	friend class Singleton<CConfiguration>;
public:
	CConfiguration(CWnd* pParent = NULL);

	enum { IDD = IDD_CONFIGURATION };
	CSkinButton	m_btnVideo;
	CSkinButton	m_btnPicture;
	CSkinButton	m_btnSave;
	CSkinButton	m_btnReLoad;
	CSkinButton	m_btnClose;
	CSkinButton	m_btnClose1;
	BOOL ReadConfig(const char* filename);
	BOOL SaveConfig(const char* filename);
	//SCinfigurationParameters m_configPara;
	CString m_strPicName;
	CString m_strVideoName;
	CUtil m_util;

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	afx_msg void OnChoosepicfolder();
	afx_msg void OnChoosevideofolder();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnBnClickedCloseenctypedlg();
	afx_msg void OnBnClickedSaveconf();
	afx_msg void OnBnClickedReload();
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedCloseconf();
	DECLARE_MESSAGE_MAP()
private:
	CBrush m_Brush;
	CTitleBase m_titleBar;
	void CreateSkin();
	CString m_strXmlFileName;
};

typedef Singleton<CConfiguration> CConfigurationSingleton;
#endif
