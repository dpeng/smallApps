#if !defined(_CODEC_BURN_DLG_H_)
#define _CODEC_BURN_DLG_H_

#if _MSC_VER > 1000
#pragma once
#endif

#include "encProcessDlg.h"
#include "wqParseStream.h"
#include "AviConv.h"
#include "xskinbutton.h"
#include "sliderbase.h"
#include "titleBar.h"
#include "encTypeDlg.h"
#include "convertToDvdDlg.h"
#include "burnDlg.h"
#include "encoder.h"
#include "VolumeDlg.h"
#include "log.h"
#include "Util.h"
#include "Configuration.h"
#include "afxwin.h"

enum _VIDEO_PLAY_STATE_ 
{ 
	State_Close  = 0,
	State_Play,
	State_Pause,
	State_Stop,
	State_Step,
	State_Encode
};

typedef struct tagPicData
{
	char* buf;
	int nSize;
	int nWidth;
	int nHeight;
	int nType;
	int isHasData;
	int nCapacity;
}capturePicData;

#define PLAYER_SLIDER_MAX	1000
class CCodecBurnDlg : public CDialog
{
public:
	CCodecBurnDlg(CWnd* pParent = NULL);

	enum { IDD = IDD_CODECBURN_DIALOG };
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	void  GetPic(char* pImage, DWORD nBufSize,long nWidth,long nHeight,long nType);
	void  SetVideoEncodeFileName(_VIDEO_ENCODE_TYPE_ videoType);
	void  ViewFullScreen();
	static DWORD WINAPI convertToAviThreadProc(LPVOID pParam);
	static DWORD WINAPI convertDvdAndBurnProc(LPVOID pParam);
	void CreateSkinBtn();
	void CreateSkinSlider();
	void ChangeBackground();
	void CreateUserDialog();

	void convertToMpeg1();
	void convertToMpeg4();
	void convertToAvi();
	void convertAndBurnDvdVideo();
	CStatic				m_staticMain;
	CStatic				m_staticPlayWindow;
	CSkinButton		m_btnMakeBgSmall;
	CSkinButton		m_btnMakeBgBig;
	CSkinButton		m_btnStop;
	CSkinButton		m_btnVolume;
	CSkinButton		m_btnAbout;
	CSkinButton		m_btnInfo;
	CSkinButton		m_btnPause;
	CSkinButton		m_btnCapture;
	CSkinButton		m_btnPlay;
	CSkinButton		m_btnFast;
	CSkinButton		m_btnSlow;
	CSkinButton		m_btnMin;
	CSkinButton		m_btnClose;
	CSkinButton		m_btnBurn;
	CSkinButton		m_btnConvert;
	CSkinButton		m_btnOpenFile;
	CSkinButton		m_btnConf;
	CString				m_strPlayStateText;
	CString				m_strPlayFileName;
	_VIDEO_PLAY_STATE_	m_enumState;
	capturePicData      m_picData;
	int					m_nSpeed;
	BOOL				m_bPause;
	BOOL				m_bVolume;
	LONG				m_nPrePlayPos;
	DWORD				m_dwMaxFileTime;
	DWORD				m_dwTotalFrames;
	DWORD				m_dwDisplaySecond;
	DWORD				m_dwDisplayMinute;
	DWORD				m_dwDisplayHour;
	CEncProcessDlg		m_dlgProcess;
	CBurnDlg			m_dlgBurn;
	CVolumeDlg			m_dlgVolume;
	CBitmap				m_smallBg;
	CBitmap				m_bigBg;
	CBitmap				m_main;
	BOOL				m_bFullScreen;
	WINDOWPLACEMENT		m_OldWndpl;
	CRect				m_rcScreen;
	DWORD				m_dwScreenHeight;
	DWORD				m_dwScreenWidth;
	LONGLONG			m_lAviFileLen;
	LONGLONG			m_lCurAviFileLen;
	CSliderBase         m_playSlider;
	CTitleBase			m_titleBar;
	BOOL				m_bBgBig;
	BOOL				m_bAviFile;
	CHAR				m_fileNameFrom[99][260];
	int					m_index;
	UINT                m_lPort;
	PARSERHANDLE		m_hStreamPraser;
	afx_msg void OnStop();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);

protected:
	HICON m_hIcon;
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnOpenFile();
	afx_msg void closeFile();
	afx_msg void OnPlay();
	afx_msg void OnInitBurn();
	afx_msg void OnPlayPause();
	afx_msg void OnGetPic();
	afx_msg void OnPlayFast();
	afx_msg void OnPlaySlow();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnClose();
	afx_msg void OnVideoenc();
	afx_msg void OnBtnClose();
	afx_msg void OnMinsize();
	afx_msg void OnMakebgbig();
	afx_msg void OnShowabout();
	afx_msg void OnVolume();
	afx_msg void OnMakebgsmall();
	afx_msg void OnBnClickedConfiguration();
	DECLARE_MESSAGE_MAP()
};

#endif