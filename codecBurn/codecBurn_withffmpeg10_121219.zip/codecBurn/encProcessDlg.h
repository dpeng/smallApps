#if !defined(AFX_ENCODINGPROCESSDLG_H__1C50C6FE_41B0_471F_B7C2_C7FFF9A87700__INCLUDED_)
#define AFX_ENCODINGPROCESSDLG_H__1C50C6FE_41B0_471F_B7C2_C7FFF9A87700__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif

#include "xskinbutton.h"
#include "titleBar.h"

class CEncProcessDlg : public CDialog
{
public:
	CEncProcessDlg(CWnd* pParent = NULL);

	enum { IDD = IDD_CODEC_PROCESS };
	virtual BOOL DestroyWindow();
	CStatic			m_encodingFile;
	CSkinButton	m_btnClose;
	CStatic			m_processInfo;
	CProgressCtrl	m_progress;
	BOOL			m_bEnd;
	int				m_nPos;
	CString			m_processInfoStr;
	CBrush			m_Brush;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	virtual BOOL OnInitDialog();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnClose();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnCloseprocessdlg();
	DECLARE_MESSAGE_MAP()
private:		
	void CreateSkin();
	CTitleBase m_titleBar;
};

#endif