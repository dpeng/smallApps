// Configuration.cpp : implementation file
//

#include "stdafx.h"
#include "codecBurn.h"
#include "Configuration.h"
#include "tinystr.h"
#include "tinyxml.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CConfiguration::CConfiguration(CWnd* pParent /*=NULL*/)
	: CDialog(CConfiguration::IDD, pParent)
{
}


void CConfiguration::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CConfiguration)
	DDX_Control(pDX, IDC_CHOOSEVIDEOFOLDER, m_btnVideo);
	DDX_Control(pDX, IDC_CHOOSEPICFOLDER, m_btnPicture);
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_SAVECONF, m_btnSave);
	DDX_Control(pDX, IDC_RELOAD, m_btnReLoad);
	DDX_Control(pDX, IDC_CLOSEENCTYPEDLG, m_btnClose);
	DDX_Control(pDX, IDC_CLOSECONF, m_btnClose1);
}


BEGIN_MESSAGE_MAP(CConfiguration, CDialog)
	//{{AFX_MSG_MAP(CConfiguration)
	ON_BN_CLICKED(IDC_CHOOSEPICFOLDER, OnChoosepicfolder)
	ON_BN_CLICKED(IDC_CHOOSEVIDEOFOLDER, OnChoosevideofolder)
	ON_WM_CTLCOLOR()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_CLOSEENCTYPEDLG, /*&CConfiguration::*/OnBnClickedCloseenctypedlg)
	ON_BN_CLICKED(IDC_SAVECONF, /*&CConfiguration::*/OnBnClickedSaveconf)
	ON_BN_CLICKED(IDC_RELOAD, /*&CConfiguration::*/OnBnClickedReload)
	ON_BN_CLICKED(IDC_CLOSECONF, /*&CConfiguration::*/OnBnClickedCloseconf)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CConfiguration message handlers

void CConfiguration::OnChoosepicfolder() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	char szDir[MAX_PATH];
	BROWSEINFO bi;
	ITEMIDLIST *pidl;
	bi.hwndOwner = this->m_hWnd;
	bi.pidlRoot = NULL;
	bi.pszDisplayName = szDir;
	bi.lpszTitle = "please choose folder";
	bi.ulFlags = BIF_STATUSTEXT | BIF_RETURNONLYFSDIRS;//BIF_STATUSTEXT | BIF_USENEWUI | BIF_RETURNONLYFSDIRS;
	bi.lpfn = NULL;
	bi.lParam = 0;
	bi.iImage = 0;
	pidl = SHBrowseForFolder(&bi);
	if(pidl == NULL)  return;
	if(!SHGetPathFromIDList(pidl, szDir))
		return;
	else
	{
		m_strPicName = szDir;
		GetDlgItem(IDC_PICTUREFOLDERNAME)->SetWindowText(m_strPicName);
	}
	UpdateData(FALSE); 
}

void CConfiguration::OnChoosevideofolder() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	char szDir[MAX_PATH];
	BROWSEINFO bi;
	ITEMIDLIST *pidl;
	bi.hwndOwner = this->m_hWnd;
	bi.pidlRoot = NULL;
	bi.pszDisplayName = szDir;
	bi.lpszTitle = "please choose folder";
	bi.ulFlags = BIF_STATUSTEXT | BIF_RETURNONLYFSDIRS;//BIF_STATUSTEXT | BIF_USENEWUI | BIF_RETURNONLYFSDIRS;
	bi.lpfn = NULL;
	bi.lParam = 0;
	bi.iImage = 0;
	pidl = SHBrowseForFolder(&bi);
	if(pidl == NULL)  return;
	if(!SHGetPathFromIDList(pidl, szDir))
		return;
	else
	{
		m_strVideoName = szDir;
		GetDlgItem(IDC_VIDEOFOLDERNAME)->SetWindowText(m_strVideoName);
	}
	UpdateData(FALSE); 
}

HBRUSH CConfiguration::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here

	pDC->SetBkMode(TRANSPARENT);
	return m_Brush;
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

BOOL CConfiguration::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	CreateSkin();
	m_Brush.CreateSolidBrush(SYSTEM_BACKCOLOR);
	m_strXmlFileName.Format("%sconfig.xml", m_util.GetCurPath());
	if (!ReadConfig(m_strXmlFileName.GetBuffer(0)))
	{
		m_strPicName.Format("%spicture", m_util.GetCurPath());
		m_strVideoName.Format("%svideo", m_util.GetCurPath());
		SaveConfig(m_strXmlFileName.GetBuffer(0));
	}
	CreateDirectory(m_strPicName.GetBuffer(0), NULL);
	CreateDirectory(m_strVideoName.GetBuffer(0), NULL);
	GetDlgItem(IDC_PICTUREFOLDERNAME)->SetWindowText(m_strPicName);
	GetDlgItem(IDC_VIDEOFOLDERNAME)->SetWindowText(m_strVideoName);
	return TRUE;
}


BOOL CConfiguration::ReadConfig(const char* filename)
{
	TiXmlDocument	_cfgDoc;
	if (!_cfgDoc.LoadFile(filename))
	{
		return false;
	}

	TiXmlElement* node = NULL;
	TiXmlElement* root = _cfgDoc.FirstChildElement("codecBurnConfig");

	if (NULL == root)
		return false;
	else
	{
		node = root->FirstChildElement("picFolder");
		if (NULL != node && NULL != node->FirstChild())
			m_strPicName = (char*)(node->FirstChild()->Value());

		node = root->FirstChildElement("videoFolder");
		if (NULL != node && NULL != node->FirstChild())
			m_strVideoName = (char*)(node->FirstChild()->Value());
	}
	return true;
}

BOOL CConfiguration::SaveConfig(const char* filename)
{
	TiXmlDocument docs;
	TiXmlNode* node = 0;
	char Vstr[256] = {0};
	if (!docs.Error())
	{
		TiXmlElement itemMessage("xml");
		itemMessage.SetAttribute("version","1.0");
		itemMessage.SetAttribute("encoding","UTF-8");

		TiXmlElement itemParameters("codecBurnConfig");

		TiXmlText textK1(m_strPicName.GetBuffer(0));
		TiXmlElement picFolder("picFolder");
		picFolder.InsertEndChild(textK1);

		TiXmlText textK2(m_strVideoName.GetBuffer(0));
		TiXmlElement videoFolder("videoFolder");
		videoFolder.InsertEndChild(textK2);

		itemParameters.InsertEndChild(picFolder);
		itemParameters.InsertEndChild(videoFolder);

		node = docs.InsertEndChild(itemMessage);
		node = docs.InsertEndChild(itemParameters);

		char xmlstr[4*1024];
		docs.DocToString(xmlstr);		
		docs.SaveFile((const char*)filename);
		return true;
	}
	else
	{
		return false;
	}
}

void CConfiguration::CreateSkin()
{
	m_titleBar.Create(CRect(0,0,520,25),this,
		IDB_COMONTITLE,IDB_COMONTITLE,
		IDB_COMONTITLE,IDB_COMONTITLE);

	m_titleBar.SetLabel("Setting: default save path");
	m_btnPicture.SetSkin(IDB_ENCBTNNORMAL, IDB_ENCBTNDOWN, IDB_ENCBTNOVER, 0, 0, 0, 0, 0, 0);
	m_btnPicture.SetTextColor(SYSTEM_BTNCOLOR);
	m_btnPicture.SizeToContent();

	m_btnVideo.SetSkin(IDB_ENCBTNNORMAL, IDB_ENCBTNDOWN, IDB_ENCBTNOVER, 0, 0, 0, 0, 0, 0);
	m_btnVideo.SetTextColor(SYSTEM_BTNCOLOR);
	m_btnVideo.SizeToContent();

	m_btnSave.SetSkin(IDB_COMONBTNNORMAL, IDB_COMONBTNDOWN, IDB_COMONBTNOVER, 0, 0, 0, 0, 0, 0);
	m_btnSave.SetTextColor(SYSTEM_BTNCOLOR);
	m_btnSave.SizeToContent();

	m_btnReLoad.SetSkin(IDB_COMONBTNNORMAL, IDB_COMONBTNDOWN, IDB_COMONBTNOVER, 0, 0, 0, 0, 0, 0);
	m_btnReLoad.SetTextColor(SYSTEM_BTNCOLOR);
	m_btnReLoad.SizeToContent();

	m_btnClose1.SetSkin(IDB_COMONBTNNORMAL, IDB_COMONBTNDOWN, IDB_COMONBTNOVER, 0, 0, 0, 0, 0, 0);
	m_btnClose1.SetTextColor(SYSTEM_BTNCOLOR);
	m_btnClose1.SizeToContent();

	m_btnClose.SetSkin(IDB_EXITNORMAL, IDB_EXITDOWN, IDB_EXITOVER, 0, 0, 0, 0, 0, 0);
	m_btnClose.SetTextColor(SYSTEM_BTNCOLOR);
	m_btnClose.SizeToContent();
}
void CConfiguration::OnBnClickedCloseenctypedlg()
{
	// TODO: Add your control notification handler code here
	//DeleteObject(m_Brush);
	CDialog::OnCancel();
}

void CConfiguration::OnBnClickedSaveconf()
{
	// TODO: Add your control notification handler code here
	if (SaveConfig(m_strXmlFileName.GetBuffer(0)))
	{
		MessageBox("Save Configuration Success!");
	} 
	else
	{
		MessageBox("Save Configuration Failed!");
	}
}

void CConfiguration::OnBnClickedReload()
{
	// TODO: Add your control notification handler code here
	if (ReadConfig(m_strXmlFileName.GetBuffer(0)))
	{
		MessageBox("Load Configuration Success!");
	} 
	else
	{
		MessageBox("Load Configuration Failed!");
	}
	GetDlgItem(IDC_PICTUREFOLDERNAME)->SetWindowText(m_strPicName);
	GetDlgItem(IDC_VIDEOFOLDERNAME)->SetWindowText(m_strVideoName);
}

void CConfiguration::OnBnClickedCloseconf()
{
	// TODO: Add your control notification handler code here
	CDialog::OnCancel();
}
