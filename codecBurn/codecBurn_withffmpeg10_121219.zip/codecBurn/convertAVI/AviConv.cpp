#include "AviConv.h"
#include "AviDef.h"
#include <stdio.h>

#ifdef WIN32
#include <windows.h>
#pragma   warning(disable:4996)
#else

#define mmioFOURCC( ch0, ch1, ch2, ch3 )				\
	( (unsigned int)(unsigned char)(ch0) | ( (unsigned int)(unsigned char)(ch1) << 8 ) |	\
		( (unsigned int)(unsigned char)(ch2) << 16 ) | ( (unsigned int)(unsigned char)(ch3) << 24 ) )

#endif

#define AVIHeaderLen (0x800)
#define MAXFRAMENUM (600*25*2)
#define SAFE_DELETE(x) {if ((x)!=NULL) {delete (x); (x)=NULL;}} 
typedef struct _AVIINFO
{
	FILE* fp;
	int rate;
	int width;
	int height;
	bool bIFrame;
	bool bAudio;
	unsigned int totalFrames;
	char idxFileName[1024];
	unsigned char audioBuf[2048];
	unsigned char aviHeaderBuf[AVIHeaderLen];
	VN_AVIINDEX aviIndexs[MAXFRAMENUM];
	int index;
	unsigned int offset;
}AVIInfo;

void put_tag(unsigned char *s, const char *tag)
{
	while(*tag)
	{
		*s++ = *tag++;
	}
}

#define PUTTAG(s, tag)			\
		{						\
			put_tag(s, tag);	\
			s = s+4;			\
		}

#define PUTLEN(s, len)			\
		{						\
			memcpy(s, &len, 4);	\
			s = s+4;			\
		}

int g711a_Decode(unsigned char *src, char *dest, int srclen, int *dstlen);

void* aviConvInit(char* aviFileName)
{
	AVIInfo* aviInfo = new AVIInfo;
	if (aviInfo == 0)
		return 0;

	memset(aviInfo, 0, sizeof(AVIInfo));
	if(!(aviInfo->fp = fopen(aviFileName, "wb")))
	{
		MessageBox(NULL, "Open File Error!", "ERROR", IDYES);
		SAFE_DELETE(aviInfo);
		return NULL;
	}
	fwrite(aviInfo->aviHeaderBuf, 1, AVIHeaderLen, aviInfo->fp);
	aviInfo->offset = 4;
	strcpy(aviInfo->idxFileName, aviFileName);
	strcat(aviInfo->idxFileName, ".idx");

	return aviInfo;
}

int aviConvAddFrame(void* handle, unsigned char* pBuf, int bufLen)
{
	AVIInfo* aviInfo = (AVIInfo*)handle;
	if (aviInfo == 0)
		return -1;

	unsigned char* ptr = pBuf;
	int len = bufLen;
	if (ptr == NULL || len <= 16)
		return -1;

	bool bVideo = true;
	bool bIFrame = false;
	unsigned int code = pBuf[3] | pBuf[2] <<8 | pBuf[1] << 16 | pBuf[0] << 24;
	switch(code)
	{
	case 0x01FD:
		aviInfo->bIFrame = true;
		bIFrame = true;
		aviInfo->rate = pBuf[5]&0x1F;
		aviInfo->width = pBuf[6]*8;
		aviInfo->height = pBuf[7]*8;
		aviInfo->totalFrames++;
		ptr = pBuf + 16;
		len = bufLen - 16;
		break;

	case 0x01FC:
		aviInfo->totalFrames++;
		ptr = pBuf + 8;
		len = bufLen - 8;
		break;

	case 0x01F0:
		if (pBuf[4] != 0xE || pBuf[5] != 0x2)
			return -1;

		g711a_Decode(pBuf + 8, (char*)aviInfo->audioBuf, bufLen - 8, &len);
		bVideo = false;
		aviInfo->bAudio = true;
		ptr = aviInfo->audioBuf;
		break;

	default:
		return -1;
	}

	if (aviInfo->bIFrame == false)
		return -1;

	static unsigned int videoTag =	mmioFOURCC('0', '0', 'd', 'c');
	static unsigned int audioTag =  mmioFOURCC('0', '1', 'w', 'b');

	VN_AVIINDEX aviIndex;

	if (bVideo)
	{
		aviIndex.ckid = videoTag;
		if (bIFrame)
			aviIndex.dwFlags = 0x10;
		else
			aviIndex.dwFlags = 0;

		fwrite(&videoTag, 1, 4, aviInfo->fp);	
	}
	else
	{
		aviIndex.ckid = audioTag;
		aviIndex.dwFlags = 0;
		fwrite(&audioTag, 1, 4, aviInfo->fp);
	}
	
	fwrite(&len, 1, 4, aviInfo->fp);
	fwrite(ptr, 1, len, aviInfo->fp);

	aviIndex.dwChunkOffset = aviInfo->offset;
	aviInfo->offset += len + 8;
	aviIndex.dwChunkLength = len;
	aviInfo->aviIndexs[aviInfo->index++] = aviIndex;	

	if (aviInfo->index >= MAXFRAMENUM)
	{
		FILE* fp;
		if (!(fp = fopen(aviInfo->idxFileName, "ab")))
		{
			MessageBox(NULL, "Open File Error!", "ERROR", IDYES);
			return 0;
		}
		fwrite(&aviInfo->aviIndexs, 1, sizeof(aviInfo->aviIndexs), fp);
		fclose(fp);
		aviInfo->index = 0;
	}

	return 0;
}

int aviConvFree(void* handle)
{
	AVIInfo* aviInfo = (AVIInfo*)handle;
	if (aviInfo == 0)
		return -1;

	VN_MainAVIHeader mainAviHeader;
	mainAviHeader.dwMicroSecPerFrame			= 40000;
	mainAviHeader.dwMaxBytesPerSec				= 50000;
	mainAviHeader.dwPaddingGranularity			= 0;
	mainAviHeader.dwFlages						= 0x910;
	mainAviHeader.dwTotalFrame					= aviInfo->totalFrames;
	mainAviHeader.dwInitialFrames				= 0;
	mainAviHeader.dwStreams						= aviInfo->bAudio ? 2 : 1;
	mainAviHeader.dwSuggestedBufferSize			= 0x100000;
	mainAviHeader.dwWidth						= aviInfo->width;
	mainAviHeader.dwHeight						= aviInfo->height;
	mainAviHeader.dwReserved[0]					= mainAviHeader.dwReserved[1] = 
		mainAviHeader.dwReserved[2]				= mainAviHeader.dwReserved[3] = 0;

	VN_AVIStreamHeader aviVideoStreamHeader;
	aviVideoStreamHeader.fccType				= mmioFOURCC('v', 'i', 'd', 's');
	aviVideoStreamHeader.fccHandler				= mmioFOURCC('H', '2', '6', '4');
	aviVideoStreamHeader.dwFlags				= 0; 
	aviVideoStreamHeader.wPriority				= 0;
	aviVideoStreamHeader.wLanguage				= 0;
	aviVideoStreamHeader.dwInitalFrames			= 0;
	if (aviInfo->rate > 27)
	{
		aviVideoStreamHeader.dwScale				= 1001;
		aviVideoStreamHeader.dwRate = 30000;
	} 
	else
	{
		aviVideoStreamHeader.dwScale				= 1;
		aviVideoStreamHeader.dwRate					= aviInfo->rate;
	}
	aviVideoStreamHeader.dwStart				= 0;
	aviVideoStreamHeader.dwLength				= aviInfo->totalFrames;
	aviVideoStreamHeader.dwSuggestedBufferSize	= 0x100000;
	aviVideoStreamHeader.dwQuality				= 0xffffffff;
	aviVideoStreamHeader.dwSampleSize			= 0;
	aviVideoStreamHeader.rcFrame.left			= aviVideoStreamHeader.rcFrame.top = 0;
	aviVideoStreamHeader.rcFrame.right			= aviInfo->width;
	aviVideoStreamHeader.rcFrame.bottom			= aviInfo->height;

	VN_AVIStreamHeader aviAudioStreamHeader;
	memset(&aviAudioStreamHeader, 0, sizeof(aviAudioStreamHeader));
	aviAudioStreamHeader.fccType				= mmioFOURCC('a', 'u', 'd', 's');
	aviAudioStreamHeader.fccHandler				= 1;
	aviAudioStreamHeader.dwFlags				= 0; 
	aviAudioStreamHeader.wPriority				= 0;
	aviAudioStreamHeader.wLanguage				= 0;
	aviAudioStreamHeader.dwInitalFrames			= 0;
	aviAudioStreamHeader.dwScale				= 1;
	aviAudioStreamHeader.dwRate					= 8000;
	aviAudioStreamHeader.dwStart				= 0;
	aviAudioStreamHeader.dwLength				= 3791;
	aviAudioStreamHeader.dwSuggestedBufferSize	= 960;
	aviAudioStreamHeader.dwQuality				= 0xffffffff;
	aviAudioStreamHeader.dwSampleSize			= 2;
	aviAudioStreamHeader.rcFrame.left			= aviVideoStreamHeader.rcFrame.top = 0;
	aviAudioStreamHeader.rcFrame.right			= 0;
	aviAudioStreamHeader.rcFrame.bottom			= 0;

	VN_BITMAPINFO bitMapInfo;
	bitMapInfo.bmiHeader.biSize = sizeof(VN_BITMAPINFOHEADER);
	bitMapInfo.bmiHeader.biWidth = aviInfo->width;
	bitMapInfo.bmiHeader.biHeight = aviInfo->height;
	bitMapInfo.bmiHeader.biPlanes = 1;
	bitMapInfo.bmiHeader.biBitCount = 24;
	bitMapInfo.bmiHeader.biCompression = mmioFOURCC('H', '2', '6', '4');
	bitMapInfo.bmiHeader.biSizeImage = aviInfo->width*aviInfo->height*3;
	bitMapInfo.bmiHeader.biXPelsPerMeter = 0;
	bitMapInfo.bmiHeader.biYPelsPerMeter = 0;
	bitMapInfo.bmiHeader.biClrUsed = 0;
	bitMapInfo.bmiHeader.biClrImportant = 0;

	VN_WAVEFORMAT waveFormat;
	waveFormat.wFormatTag = 1;//PCM
	waveFormat.nChannels = 1;
	waveFormat.nSamplesPerSec = 8000;
	waveFormat.nAvgBytesPerSec = 16000;
	waveFormat.nBlockAlign = 2;
	waveFormat.biSize = 16;

	int idxLen = aviInfo->index*sizeof(VN_AVIINDEX);
	FILE* idxfp = fopen(aviInfo->idxFileName, "rb");
	if (idxfp != 0)
	{
		fseek(idxfp, 0, SEEK_END);
		int idxfileLen = ftell(idxfp);
		idxLen += idxfileLen;
	}

	fseek(aviInfo->fp, 0, SEEK_END);
	int fileLen = ftell(aviInfo->fp);
	if(fileLen%2 == 1)
	{
		fwrite("0", 1, 1, aviInfo->fp);
		fileLen += 1;
	}

	unsigned char* bufptr = aviInfo->aviHeaderBuf;
	PUTTAG(bufptr, "RIFF");
	int totalLen = fileLen + (idxLen + 8) - 8; 
	PUTLEN(bufptr, totalLen);
	PUTTAG(bufptr, "AVI ");

	//hdrl
	PUTTAG(bufptr, "LIST");
	int videoSTRLLen = 4 + 8 + sizeof(VN_AVIStreamHeader) + 8 + sizeof(VN_BITMAPINFO);
	int audioSTRLLen = 4 + 8 + sizeof(VN_AVIStreamHeader) + 8 + sizeof(VN_WAVEFORMAT);

	int dhrlLen = 12 + sizeof(VN_MainAVIHeader) + 8 + videoSTRLLen;
	if (aviInfo->bAudio)
		dhrlLen += (audioSTRLLen+8);

	PUTLEN(bufptr, dhrlLen);
	PUTTAG(bufptr, "hdrl");

	//avimainheader
	PUTTAG(bufptr, "avih");
	int mainAviHeaderLen = sizeof(VN_MainAVIHeader);
	PUTLEN(bufptr, mainAviHeaderLen);
	memcpy(bufptr, &mainAviHeader, mainAviHeaderLen);
	bufptr += mainAviHeaderLen;

	//strl
	PUTTAG(bufptr, "LIST");
	int strlLen = videoSTRLLen;
	PUTLEN(bufptr, strlLen);
	PUTTAG(bufptr, "strl");

	//strh
	PUTTAG(bufptr, "strh");
	int strhLen = sizeof(VN_AVIStreamHeader);
	PUTLEN(bufptr, strhLen);
	memcpy(bufptr, &aviVideoStreamHeader, strhLen);
	bufptr += strhLen;

	//strf
	PUTTAG(bufptr, "strf");
	int strfLen = sizeof(VN_BITMAPINFO);
	PUTLEN(bufptr, strfLen);
	memcpy(bufptr, &bitMapInfo, strfLen);
	bufptr += strfLen;
	
	if (aviInfo->bAudio)
	{
		//strl
		PUTTAG(bufptr, "LIST");
		int strlLen = audioSTRLLen;
		PUTLEN(bufptr, strlLen);
		PUTTAG(bufptr, "strl");
		
		//strh
		PUTTAG(bufptr, "strh");
		int strhLen = sizeof(VN_AVIStreamHeader);
		PUTLEN(bufptr, strhLen);
		memcpy(bufptr, &aviAudioStreamHeader, strhLen);
		bufptr += strhLen;
		
		//strf
		PUTTAG(bufptr, "strf");
		int strfLen = sizeof(VN_WAVEFORMAT);
		PUTLEN(bufptr, strfLen);
		memcpy(bufptr, &waveFormat, strfLen);
		bufptr += strfLen;
	}

	//JUNK
	PUTTAG(bufptr, "JUNK");
	int JUNKLen = AVIHeaderLen - (bufptr - aviInfo->aviHeaderBuf) - 4 - 12;
	PUTLEN(bufptr, JUNKLen);
	bufptr += JUNKLen;

	//movi
	PUTTAG(bufptr, "LIST");
	int moviLen = fileLen - AVIHeaderLen + 4;
	PUTLEN(bufptr, moviLen);
	PUTTAG(bufptr, "movi");

	fseek(aviInfo->fp, 0, SEEK_SET);
	fwrite(aviInfo->aviHeaderBuf, 1, AVIHeaderLen, aviInfo->fp);

	//idx1
	fseek(aviInfo->fp, 0, SEEK_END);
	fwrite("idx1", 1, 4, aviInfo->fp);

	fwrite(&idxLen, 1, 4, aviInfo->fp);
	if (idxfp != 0)
	{
		const int tmpBufLen = 50*1024;
		char* buf = new char[tmpBufLen];
		fseek(idxfp, 0, SEEK_SET);

		while(1)
		{
			int readLen = fread(buf, 1, tmpBufLen, idxfp);
			if (readLen <= 0)
				break;
			fwrite(buf, 1, readLen, aviInfo->fp);
		}
		delete []buf;
	}

	fwrite(&aviInfo->aviIndexs, 1, aviInfo->index*sizeof(VN_AVIINDEX), aviInfo->fp);

 	memset(aviInfo->aviHeaderBuf, 0, 16);
 	fwrite(aviInfo->aviHeaderBuf, 1, 16, aviInfo->fp);
	
	fclose(aviInfo->fp);
	delete aviInfo;

	if (idxfp)
	{
		fclose(idxfp);
		/*---------?----------*/
	}

	return 0;
}


signed short A2l[256] = 
{
	-5504, -5248, -6016, -5760, -4480, -4224, -4992, -4736,
		-7552, -7296, -8064, -7808, -6528, -6272, -7040, -6784,
		-2752, -2624, -3008, -2880, -2240, -2112, -2496, -2368,
		-3776, -3648, -4032, -3904, -3264, -3136, -3520, -3392,
		-22016,-20992,-24064,-23040,-17920,-16896,-19968,-18944,
		-30208,-29184,-32256,-31232,-26112,-25088,-28160,-27136,
		-11008,-10496,-12032,-11520, -8960, -8448, -9984, -9472,
		-15104,-14592,-16128,-15616,-13056,-12544,-14080,-13568,
		-344,  -328,  -376,  -360,  -280,  -264,  -312,  -296,
		-472,  -456,  -504,  -488,  -408,  -392,  -440,  -424,
		-88,   -72,  -120,  -104,   -24,    -8,   -56,   -40,
		-216,  -200,  -248,  -232,  -152,  -136,  -184,  -168,
		-1376, -1312, -1504, -1440, -1120, -1056, -1248, -1184,
		-1888, -1824, -2016, -1952, -1632, -1568, -1760, -1696,
		-688,  -656,  -752,  -720,  -560,  -528,  -624,  -592,
		-944,  -912, -1008,  -976,  -816,  -784,  -880,  -848,
		5504,  5248,  6016,  5760,  4480,  4224,  4992,  4736,
		7552,  7296,  8064,  7808,  6528,  6272,  7040,  6784,
		2752,  2624,  3008,  2880,  2240,  2112,  2496,  2368,
		3776,  3648,  4032,  3904,  3264,  3136,  3520,  3392,
		22016, 20992, 24064, 23040, 17920, 16896, 19968, 18944,
		30208, 29184, 32256, 31232, 26112, 25088, 28160, 27136,
		11008, 10496, 12032, 11520,  8960,  8448,  9984,  9472,
		15104, 14592, 16128, 15616, 13056, 12544, 14080, 13568,
		344,   328,   376,   360,   280,   264,   312,   296,
		472,   456,   504,   488,   408,   392,   440,   424,
		88,    72,   120,   104,    24,     8,    56,    40,
		216,   200,   248,   232,   152,   136,   184,   168,
		1376,  1312,  1504,  1440,  1120,  1056,  1248,  1184,
		1888,  1824,  2016,  1952,  1632,  1568,  1760,  1696,
		688,   656,   752,   720,   560,   528,   624,   592,
		944,   912,  1008,   976,   816,   784,   880,   848,
};

int g711a_Decode(unsigned char *src, char *dest, int srclen, int *dstlen)
{
	int	i;
	
	unsigned short *pd=(unsigned short*)dest;
	
	for(i=0; i<srclen; i++)	
		pd[i]=(unsigned short)A2l[src[i]];
	
	*dstlen = srclen<<1;
	
	return 1;
}