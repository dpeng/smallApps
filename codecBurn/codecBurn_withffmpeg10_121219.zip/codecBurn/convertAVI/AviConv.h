#ifndef _AVICONV_H
#define _AVICONV_H

void* aviConvInit(char* aviFileName);
int aviConvAddFrame(void* handle, unsigned char* pBuf, int bufLen);
int aviConvFree(void* handle);

#endif
