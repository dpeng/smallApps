#include "Util.h"

CUtil::CUtil(void)
{
}

CUtil::~CUtil(void)
{
}

CString CUtil::getFileSuffix(CString src)
{
	CString dest = _T("");
	char filename[MAX_PATH];
	memset(&filename, NULL, MAX_PATH);
	UINT len = strlen(src.GetBuffer(0)) + 1;
	if (len < MAX_PATH)
	{
		memcpy(filename, src.GetBuffer(0), len);
	} 
	else
	{
		return _T("err");
	}
	len = strlen(filename) + 1;
	dest = &filename[len-4];
	return dest;
}

char* CUtil::GetCurPath()
{
	static TCHAR buf[MAX_PATH] = {0};
	HMODULE handle = GetModuleHandle("vnplayer.dll");
	DWORD length = ::GetModuleFileName(handle, buf, MAX_PATH);
	if (length <= 0)
		return _T("C:\\");
	--length;
	for (; length>0; --length)
		if (buf[length] == '/' || buf[length] == '\\')
		{
			buf[length + 1] = 0;
			break;
		}
	return buf;
}

CString CUtil::GetGUIDStr()
{
	GUID pguid;
	CString tmpStr = _T("");
	CoCreateGuid( &pguid );    
	WCHAR wcharGUID[40];
	StringFromGUID2(pguid,wcharGUID,40);
	tmpStr = wcharGUID;
	return tmpStr;
}
