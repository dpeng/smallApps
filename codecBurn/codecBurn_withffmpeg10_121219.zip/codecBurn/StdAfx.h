#if !defined(AFX_STDAFX_H__9AF02E33_A66E_4D78_96A7_09C160723BCA__INCLUDED_)
#define AFX_STDAFX_H__9AF02E33_A66E_4D78_96A7_09C160723BCA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif
#pragma   warning(disable:4996)
#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#define WINVER 0x0501

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

static const long SYSTEM_BACKCOLOR = RGB(75,75,75);
static const long SYSTEM_BTNCOLOR = RGB(198,206,225);
#define SAFE_DELETE(x) {if ((x)!=NULL) {delete (x); (x)=NULL;}} 
#define MAX_TRACKS 99
#endif // !defined(AFX_STDAFX_H__9AF02E33_A66E_4D78_96A7_09C160723BCA__INCLUDED_)
