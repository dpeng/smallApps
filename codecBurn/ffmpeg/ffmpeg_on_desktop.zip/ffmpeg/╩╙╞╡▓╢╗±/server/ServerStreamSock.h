#if !defined(AFX_SERVERSTREAMSOCK_H__6DE243D9_6186_4ED6_9F39_FEC46CBE8C23__INCLUDED_)
#define AFX_SERVERSTREAMSOCK_H__6DE243D9_6186_4ED6_9F39_FEC46CBE8C23__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ServerStreamSock.h : header file
//



/////////////////////////////////////////////////////////////////////////////
// CServerStreamSock command target

class CServerStreamSock : public CAsyncSocket
{
// Attributes
public:

// Operations
public:
	CServerStreamSock();
	virtual ~CServerStreamSock();

// Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CServerStreamSock)
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CServerStreamSock)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
protected:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SERVERSTREAMSOCK_H__6DE243D9_6186_4ED6_9F39_FEC46CBE8C23__INCLUDED_)
