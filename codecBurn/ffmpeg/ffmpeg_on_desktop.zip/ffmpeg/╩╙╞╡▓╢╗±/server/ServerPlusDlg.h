// ServerPlusDlg.h : header file
//

#if !defined(AFX_SERVERPLUSDLG_H__2C96A858_E660_457A_9A4B_6A44617043C1__INCLUDED_)
#define AFX_SERVERPLUSDLG_H__2C96A858_E660_457A_9A4B_6A44617043C1__INCLUDED_

#include "ServerCtrlSock.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CServerPlusDlg dialog
#include "vfw.h"
#include "ListenSock.h"	// Added by ClassView
#include "ServerStreamSock.h"	// Added by ClassView
#pragma comment(lib,"vfw32.lib")

typedef struct _SERVER_CTRL_MSG
{
	char strCommand[100];
	DWORD nContentUsedByte;
	char strContent[1000];
}SERVER_CTRL_MSG;

typedef struct _VIDEO_DATA
{
	BOOL bKeyFrame;
	DWORD nSampleNum;
	DWORD nUsedSize;
	BYTE Buf[8180];
}VIDEO_DATA;

class CServerPlusDlg : public CDialog
{
// Construction
public:
	BOOL m_bConnect;
	DWORD m_SampleNum;
	CServerCtrlSock m_ServerCtrlSock;
	CServerStreamSock m_ServerStreamSock;
	void InitNetWork();
	CListenSock m_ListenSock;
	void FillBitmapStruct();
	void CompressFrame(LPVIDEOHDR lpVHdr);
	static LRESULT CALLBACK FrameCallBack(HWND hWnd,LPVIDEOHDR lpVHdr);
	void UnInitVideoCard();
	void InitVideoCard();
	void UnInitCompressor();
	void InitCompressor();
	HWND m_hWndCapture;
	DWORD m_OutFormatSize,m_OutBufferSize;
	long m_OutActSize;
	BITMAPINFO m_InInfo,*m_pOutInfo;
	COMPVARS m_CV;
	CServerPlusDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CServerPlusDlg)
	enum { IDD = IDD_SERVERPLUS_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CServerPlusDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CServerPlusDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SERVERPLUSDLG_H__2C96A858_E660_457A_9A4B_6A44617043C1__INCLUDED_)
