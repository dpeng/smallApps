// ServerStreamSock.cpp : implementation file
//

#include "stdafx.h"
#include "ServerPlus.h"
#include "ServerStreamSock.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CServerStreamSock

CServerStreamSock::CServerStreamSock()
{
}

CServerStreamSock::~CServerStreamSock()
{
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CServerStreamSock, CAsyncSocket)
	//{{AFX_MSG_MAP(CServerStreamSock)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CServerStreamSock member functions
