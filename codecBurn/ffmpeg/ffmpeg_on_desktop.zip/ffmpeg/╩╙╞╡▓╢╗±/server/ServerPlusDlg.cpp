// ServerPlusDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ServerPlus.h"
#include "ServerPlusDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CServerPlusDlg dialog

CServerPlusDlg::CServerPlusDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CServerPlusDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CServerPlusDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CServerPlusDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CServerPlusDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CServerPlusDlg, CDialog)
	//{{AFX_MSG_MAP(CServerPlusDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CServerPlusDlg message handlers

BOOL CServerPlusDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	this->m_bConnect=FALSE;
	this->m_SampleNum=0;
	this->FillBitmapStruct();
	this->InitVideoCard();
	this->InitCompressor();
	this->InitNetWork();
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CServerPlusDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CServerPlusDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CServerPlusDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CServerPlusDlg::UnInitCompressor()
{
	if (m_CV.hic!=NULL)
	{
		delete[] m_pOutInfo;
		::ICSeqCompressFrameEnd(&m_CV);
		ICCompressorFree(&m_CV);
		ICClose(m_CV.hic);
	}

}

void CServerPlusDlg::InitCompressor()
{
////////Let the user select the compressor and fill the COMPVRAS Struct automatically
/*	
	m_CV.cbSize=sizeof(m_CV);	
    ICCompressorChoose(this->m_hWnd,0,NULL,NULL,&m_CV,"Choose a Compressor");
	afxDump<<m_CV.lKeyCount<<"\n";
*/	
////////Fill the COMPVRAS Struct manually
	
    memset(&m_CV,0,sizeof(COMPVARS));
	m_CV.dwFlags=ICMF_COMPVARS_VALID;
	m_CV.cbSize=sizeof(m_CV);
	m_CV.cbState=0;
	m_CV.fccHandler=mmioFOURCC('d','i','v','x');
	m_CV.fccType=ICTYPE_VIDEO;
	m_CV.hic=ICOpen(ICTYPE_VIDEO,mmioFOURCC('d','i','v','x'),ICMODE_COMPRESS);
	m_CV.lDataRate=780;
	m_CV.lFrame=0;
	m_CV.lKey=15;
	m_CV.lKeyCount=0;
	m_CV.lpbiIn=NULL;
	m_CV.lpBitsOut=NULL;
	m_CV.lpBitsPrev=m_CV.lpState=NULL;
	m_CV.lQ=ICQUALITY_DEFAULT;
	
	if (m_CV.hic!=NULL)
	{
		m_OutFormatSize=ICCompressGetFormatSize(m_CV.hic,&m_InInfo);
	    m_pOutInfo=(BITMAPINFO *)new BYTE[m_OutFormatSize];
	    ICCompressGetFormat(m_CV.hic,&m_InInfo,m_pOutInfo);

		m_OutBufferSize=ICCompressGetSize(m_CV.hic,&m_InInfo,m_pOutInfo);
		
		ICSeqCompressFrameStart(&m_CV,&m_InInfo);
	}
}

void CServerPlusDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here
	this->UnInitCompressor();
	this->UnInitVideoCard();
	
}

void CServerPlusDlg::InitVideoCard()
{
	this->m_hWndCapture=::capCreateCaptureWindow("Capture Window",WS_VISIBLE|WS_CHILD,0,0,320,240,this->m_hWnd,1);
	capDriverConnect(this->m_hWndCapture,0);
	//set the video format 
	capSetVideoFormat(this->m_hWndCapture,&this->m_InInfo,sizeof(BITMAPINFO));
	
	capPreviewRate(this->m_hWndCapture,40);
//	capDlgVideoFormat(this->m_hWndCapture);
	capPreview(this->m_hWndCapture,TRUE);
	capSetCallbackOnFrame(this->m_hWndCapture,FrameCallBack);
}

void CServerPlusDlg::UnInitVideoCard()
{
	capSetCallbackOnFrame(this->m_hWndCapture,FrameCallBack);
	capDriverDisconnect(this->m_hWndCapture);
}

LRESULT CALLBACK CServerPlusDlg::FrameCallBack(HWND hWnd, LPVIDEOHDR lpVHdr)
{ 
	CServerPlusDlg* pDlg=(CServerPlusDlg*)::AfxGetMainWnd();
	if (pDlg->m_bConnect==TRUE)
	{

		pDlg->CompressFrame(lpVHdr);
	}
	return TRUE;
}

void CServerPlusDlg::CompressFrame(LPVIDEOHDR lpVHdr)
{
	BOOL bKeyFrame;
	m_OutActSize=this->m_InInfo.bmiHeader.biSizeImage;
	BYTE* Buf=(BYTE*)ICSeqCompressFrame(&m_CV,0,lpVHdr->lpData,&bKeyFrame,(long*)&m_OutActSize);
	afxDump<<"Compressed size:"<<m_OutActSize<<"\n";
	if (this->m_bConnect==TRUE && m_OutActSize<8180)
	{
		//send the video data to client.
		VIDEO_DATA VideoData;
		memset(&VideoData,0,sizeof(VIDEO_DATA));
		VideoData.bKeyFrame=bKeyFrame;
		
		memcpy(VideoData.Buf,Buf,m_OutActSize);
		
		VideoData.nSampleNum=this->m_SampleNum;
		VideoData.nUsedSize=m_OutActSize;
		
		this->m_ServerStreamSock.Send(&VideoData,sizeof(VIDEO_DATA));

		m_SampleNum+=1;
	}

}

void CServerPlusDlg::FillBitmapStruct()
{
	m_InInfo.bmiHeader.biBitCount=24;
	m_InInfo.bmiHeader.biClrImportant=m_InInfo.bmiHeader.biClrUsed=0;
	m_InInfo.bmiHeader.biCompression=BI_RGB;
	m_InInfo.bmiHeader.biHeight=240;
	m_InInfo.bmiHeader.biPlanes=1;
	m_InInfo.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);
	m_InInfo.bmiHeader.biSizeImage=0;
	m_InInfo.bmiHeader.biWidth=320;
	m_InInfo.bmiHeader.biXPelsPerMeter=m_InInfo.bmiHeader.biYPelsPerMeter=0;
}

void CServerPlusDlg::InitNetWork()
{
	::AfxSocketInit();
	m_ListenSock.Create(5555,SOCK_STREAM,FD_ACCEPT);
	m_ListenSock.Listen();
}
