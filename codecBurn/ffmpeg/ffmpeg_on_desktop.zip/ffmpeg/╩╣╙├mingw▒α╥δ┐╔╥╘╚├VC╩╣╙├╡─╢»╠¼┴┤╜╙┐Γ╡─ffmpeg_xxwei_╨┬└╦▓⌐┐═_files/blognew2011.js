var BLOG_AD = {
	"scroll":{
		'ad': 1,
		'rtt': 1,
		'adnum': 2,
		'ads':{
			'0':{
				//<!-- ��ʱ�е�1֡ ��ʼ -->
				// ��ʼʱ��
				'startdate':'2011-4-25',
				// ����ʱ��
				'enddate':'2011-4-29 10:00:00',
				'warp': 1,
				'ads':{
					'0':{
						//<!-- ��ť -->
						// ���ͣ�swf��pic
						"type":"swf",
						"pos":"scroll",
						"width":140,
						"height":150,
						// �����ַ
						"click":"http://sina.allyes.com/main/adfclick?db=sina&bid=256108,311804,317093&cid=0,0,0&sid=311223&advid=7610&camid=47953&show=ignore&url=http://ad-apac.doubleclick.net/click;h=v2|3DAB|0|0|%2a|o;238897343;0-0;0;61876921;31-1|1;41286698|41304485|1;;%3fhttp://www.dove.com.cn/beautystory?utm_source=SinaWeibo&utm_medium=CPD&utm_term=v1&utm_content=DS17&utm_campaign=UL_Dove_Master_Band",
						// �������
						"status": {
							"adstart":"",
							"adend":"",
							"adclose":""
						},
						// �زĵ�ַ
						"ref":"http://d2.sina.com.cn/jianyu1/Dove/new-contract/140x150-20k.jpg",
						// ����(type)Ϊ���mixed����
						"content":''
					},
					'1':{
						//<!-- С��ť -->
						// ���ͣ�swf��pic
						"type":"swf",
						"pos":"scroll",
						"width":25,
						"height":150,
						// �����ַ
						"click":"http://sina.allyes.com/main/adfclick?db=sina&bid=256108,311804,317093&cid=0,0,0&sid=311223&advid=7610&camid=47953&show=ignore&url=http://ad-apac.doubleclick.net/click;h=v2|3DAB|0|0|%2a|o;238897343;0-0;0;61876921;31-1|1;41286698|41304485|1;;%3fhttp://www.dove.com.cn/beautystory?utm_source=SinaWeibo&utm_medium=CPD&utm_term=v1&utm_content=DS17&utm_campaign=UL_Dove_Master_Band",
						// �������
						"status": {
							"adstart":"",
							"adend":"",
							"adclose":""
						},
						// �زĵ�ַ
						"ref":"http://d5.sina.com.cn/jianyu1/Dove/new-contract/25x150-10k.jpg",
						// ����(type)Ϊ���mixed����
						"content":''
					}
				}
				//<!-- ��ʱ�е�1֡ ���� -->
			},
			'1':{
				//<!-- ��ʱ�е�1֡ ��ʼ -->
				// ��ʼʱ��
				'startdate':'2011-4-25',
				// ����ʱ��
				'enddate':'2011-4-29 10:00:00',
				'warp': 1,
				'ads':{
					'0':{
						//<!-- ��ť -->
						// ���ͣ�swf��pic
						"type":"swf",
						"pos":"scroll",
						"width":140,
						"height":150,
						// �����ַ
						"click":"http://sina.allyes.com/main/adfclick?db=sina&bid=256108,311804,317093&cid=0,0,0&sid=311223&advid=7610&camid=47953&show=ignore&url=http://ad-apac.doubleclick.net/click;h=v2|3DAB|0|0|%2a|o;238897343;0-0;0;61876921;31-1|1;41286698|41304485|1;;%3fhttp://www.dove.com.cn/beautystory?utm_source=SinaWeibo&utm_medium=CPD&utm_term=v1&utm_content=DS17&utm_campaign=UL_Dove_Master_Band",
						// �������
						"status": {
							"adstart":"",
							"adend":"",
							"adclose":""
						},
						// �زĵ�ַ
						"ref":"http://d2.sina.com.cn/jianyu1/Dove/new-contract/140x150-20k.jpg",
						// ����(type)Ϊ���mixed����
						"content":''
					},
					'1':{
						//<!-- С��ť -->
						// ���ͣ�swf��pic
						"type":"swf",
						"pos":"scroll",
						"width":25,
						"height":150,
						// �����ַ
						"click":"http://sina.allyes.com/main/adfclick?db=sina&bid=256108,311804,317093&cid=0,0,0&sid=311223&advid=7610&camid=47953&show=ignore&url=http://ad-apac.doubleclick.net/click;h=v2|3DAB|0|0|%2a|o;238897343;0-0;0;61876921;31-1|1;41286698|41304485|1;;%3fhttp://www.dove.com.cn/beautystory?utm_source=SinaWeibo&utm_medium=CPD&utm_term=v1&utm_content=DS17&utm_campaign=UL_Dove_Master_Band",
						// �������
						"status": {
							"adstart":"",
							"adend":"",
							"adclose":""
						},
						// �زĵ�ַ
						"ref":"http://d5.sina.com.cn/jianyu1/Dove/new-contract/25x150-10k.jpg",
						// ����(type)Ϊ���mixed����
						"content":''
					}
				}
				//<!-- ��ʱ�е�1֡ ���� -->
			}
		}
	},

	"comment":{
		'ad': 0,
		'adnum': 3,
		'ads':{
			'0':{
				"type":"txt",
				"pos":"comment",
				"width":0,
				"height":0,
				"title":"�����������µĺð취",
				"click":"http://sina.allyes.com/main/adfclick?db=sina&bid=204720,299858,305134&cid=0,0,0&sid=298937&advid=358&camid=37389&show=ignore&url=http://blog.sina.com.cn/s/blog_705463570100pfv9.html?tj=1",
				"status": {
					"adstart":"",
					"adend":"",
					"adclose":""
				}
			},
			'1':{
				"type":"txt",
				"pos":"comment",
				"width":0,
				"height":0,
				"title":"��עÿ�������Ų���",
				"click":"http://sina.allyes.com/main/adfclick?db=sina&bid=118883,251213,256255&cid=0,0,0&sid=247096&advid=358&camid=19809&show=ignore&url=http://weibo.com/blogkefu",
				"status": {
					"adstart":"",
					"adend":"",
					"adclose":""
				}
			},
			'2':{
				"type":"txt",
				"pos":"comment",
				"width":0,
				"height":0,
				"title":"��߲��������·���",
				"click":"http://sina.allyes.com/main/adfclick?db=sina&bid=204720,299859,305135&cid=0,0,0&sid=298939&advid=358&camid=37389&show=ignore&url=http://blog.sina.com.cn/s/blog_705463570100phtd.html?tj=1",
				"status": {
					"adstart":"",
					"adend":"",
					"adclose":""
				}
			}
		}

	},

	"video":{
		'ad': 1,
		'adnum': 2,
		'rtt': 1,
		'ads':{
			'0':{
				//<!-- �رպ�ť��1֡ ��ʼ -->
				// ���ͣ�swf��pic
				"type":"swf",
				"pos":"video",
				// ��ʼʱ��
				"startdate":"2011-4-29 10:00:00",
				// ����ʱ��
				"enddate":"2011-4-30 10:00:00",
				"width":260,
				"height":190,
				// �����ַ
				"click":"http://sina.allyes.com/main/adfclick?db=sina&bid=258947,314732,320021&cid=0,0,0&sid=314240&advid=9614&camid=48611&show=ignore&url=http://e.miaozhen.com/r.gif?%5Ek=1808%5Ep=Bd60%5Eae=%5Eo=http://shilipk.head-shoulders.com.cn",
				// �������
				"status": {
					"adstart":"",
					"adend":"",
					"adclose":""
				},
				// �زĵ�ַ
				"ref":"http://d2.sina.com.cn/201104/15/297597_blog-260190.swf",
				"content":''
				//<!-- �رպ�ť��1֡ ���� -->
			},
			'1':{
				//<!-- �رպ�ť��2֡ ��ʼ -->
				// ���ͣ�swf��pic
				"type":"swf",
				"pos":"video",
				// ��ʼʱ��
				"startdate":"2011-4-27 10:00:00",
				// ����ʱ��
				"enddate":"2011-4-30 10:00:00",
				"width":260,
				"height":190,
				// �����ַ
				"click":"http://sina.allyes.com/main/adfclick?db=sina&bid=261692,317671,322960&cid=0,0,0&sid=317273&advid=7610&camid=49206&show=ignore&url=http://ad-apac.doubleclick.net/click;h=v2|3DB5|0|0|%2a|d;239429980;0-0;0;62309507;31-1|1;41500227|41518014|1;;%3fhttp://all.vic.sina.com.cn/ponds/?utm_source=Sina&utm_medium=CPD&utm_term=v1&utm_content=PH05&utm_campaign=Huli",
				// �������
				"status": {
					"adstart":"",
					"adend":"",
					"adclose":""
				},
				// �زĵ�ַ
				"ref":"http://d4.sina.com.cn/jianyu1/ponds/RPM0002388/bk-fdck-gban_260x190_20k.swf",
				"content":''
				//<!-- �رպ�ť��2֡ ���� -->
			}
		}
	},

	"leftsx":{
		'ad': 0,
		'adnum': 1,
		'ads':{
			'0':{
				"type":"iframe",
				"pos":"leftsx",
				'startdate':'2011-4-23',
				'enddate':'2011-4-29',
				"width":190,
				"height":200,
				"click":"",
				"status": {
					"adstart":"",
					"adend":"",
					"adclose":""
				},
				"ref":"",
				"content":''
			}
		}
	},

	"topbanner":{
		'ad': 1,
		'adnum': 2,
		'rtt': 1,
		'ads':{
			'0':{
				//<!-- ��ͨ��1֡ ��ʼ -->
				// ���ͣ�swf��pic
				"type":"swf",
				"pos":"topbanner",
				"width":950,
				"height":30,
				// ��ʼʱ��
				'startdate':'2011-5-4 9:00:00',
				// ����ʱ��
				'enddate':'2011-5-5 9:00:00',
				// �����ַ
				"click":"http://sina.allyes.com/main/adfclick?db=sina&bid=262874,318912,324203&cid=0,0,0&sid=318572&advid=1293&camid=49508&show=ignore&url=http://www.ihush.com/index.php?sourcename=Sinatest&sourcetype=5",
				// �������
				"status": {
					"adstart":"",
					"adend":"",
					"adclose":""
				},
				// �زĵ�ַ
				"ref":"http://d5.sina.com.cn/201104/29/301853_95030blog_tjbw_sx_0429.swf",
				// ����(type)Ϊ���mixed����
				"content":''
				//<!-- ��ͨ��1֡ ���� -->
			},
			'1':{
				//<!-- ��ͨ��2֡ ��ʼ -->
				// ���ͣ�swf��pic
				"type":"swf",
				"pos":"topbanner",
				"width":950,
				"height":30,
				// ��ʼʱ��
				'startdate':'2011-4-23',
				// ����ʱ��
				'enddate':'2011-4-29',
				// �����ַ
				"click":"http://www.ihush.com/index.php?sourcename=Sinatest&sourcetype=5",
				// �������
				"status": {
					"adstart":"",
					"adend":"",
					"adclose":""
				},
				// �زĵ�ַ
				"ref":"",
				// ����(type)Ϊ���mixed����
				"content":''
				//<!-- ��ͨ��2֡ ���� -->
			}
		}
	},

	"jumpin": {
		'ad':0,
		'adnum': 1,
		'ads':{
			'0':{
				"type":"swf",
				"pos":"jumpin",
				"width":240,
				"height":60,
				'startdate':'2011-4-23',
				'enddate':'2011-4-29',
				"click":"http://www.sina.com.cn/",
				"status": {
					"adstart":"",
					"adend":"",
					"adclose":""
				},

				"ref":"",
				"content":''
			}
		}
	}

};

//var BLOG_AD = null;
