DOS batch files for MinGW + MSYS toolchains

Here are some DOS batch files for downloading and installing MinGW + MSYS toolchains
automatically. With the help of these batch files, you could get the MinGW + MSYS
toolchains by selecting operations in menu form.

Extract the zip to your local disk, then run "main.bat" by double-click it in explorer.

Enjoy it.

http://www.FFmpegWindows.org
