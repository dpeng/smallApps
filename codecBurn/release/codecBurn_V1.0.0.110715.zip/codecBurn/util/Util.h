#ifndef _UTIL_H_____
#define _UTIL_H_____
#pragma once
#include "../StdAfx.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

class CUtil
{
public:
	CUtil(void);
public:
	~CUtil(void);
	CString getFileSuffix(CString src);
	char *GetCurPath();
	CString GetGUIDStr();
};
#endif