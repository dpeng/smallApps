#if !defined(_ENCODE_TYPE_H_)
#define _ENCODE_TYPE_H_

#if _MSC_VER > 1000
#pragma once
#endif

#include "xskinbutton.h"
#include "titleBar.h"
#include "Util.h"
#include "Configuration.h"

enum _VIDEO_ENCODE_TYPE_
{
	NULL_ENCODE  = 0,
	MPEG1_ENCODE = 1,
	MPEG4_ENCODE = 2,
	AVI_ENCODE   = 3
};

class CEncTypeDlg : public CDialog
{

public:
	CEncTypeDlg(CWnd* pParent = NULL);
	afx_msg void OnBnClickedOk();

	enum { IDD = IDD_ENCTYPE };
	CxSkinButton	m_btnEncTo;
	CxSkinButton	m_btnEncFrom;
	CxSkinButton	m_btnClose;
	CxSkinButton	m_btnCancel;
	CxSkinButton	m_btnOk;
	_VIDEO_ENCODE_TYPE_ m_encType;
	CString			m_strFromFile;
	CString			m_strToFile;
	CString			m_strTmpToFile;
	BOOL			m_bAviFile;

private:
	CBrush m_Brush;
	void CreateSkin();
	CTitleBase m_titleBar;

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	virtual BOOL OnInitDialog();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnCloseenctypedlg();
	afx_msg void OnEncodeFromBtn();
	afx_msg void OnEncodeToBtn();
	virtual void OnOK();
	virtual void OnCancel();
	DECLARE_MESSAGE_MAP()
};

#endif