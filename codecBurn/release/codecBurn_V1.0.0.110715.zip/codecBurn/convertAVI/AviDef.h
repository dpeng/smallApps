#ifndef _AVIDEF_H
#define _AVIDEF_H

typedef struct   
{  
	unsigned int dwMicroSecPerFrame ; 
	unsigned int dwMaxBytesPerSec; 
	unsigned int dwPaddingGranularity; 
	unsigned int dwFlages; 
	unsigned int dwTotalFrame;
	unsigned int dwInitialFrames;
	unsigned int dwStreams;
	unsigned int dwSuggestedBufferSize;
	unsigned int dwWidth;
	unsigned int dwHeight;
	unsigned int dwReserved[4];
}VN_MainAVIHeader; 

typedef struct
{
	unsigned short left;
	unsigned short top;
	unsigned short right;
	unsigned short bottom;
}RECT2;

typedef struct   
{ 
	unsigned int fccType; 
	unsigned int fccHandler;
	unsigned int dwFlags;
	unsigned short wPriority;
	unsigned short wLanguage;
	unsigned int dwInitalFrames;
	unsigned int dwScale;
	unsigned int dwRate;
	unsigned int dwStart;
	unsigned int dwLength;
	unsigned int dwSuggestedBufferSize;
	unsigned int dwQuality;
	unsigned int dwSampleSize;
	RECT2 rcFrame;
}VN_AVIStreamHeader; 

typedef struct tagVN_BITMAPINFOHEADER 
{ 
	unsigned int biSize; 
	long biWidth; 
	long biHeight; 
	unsigned short biPlanes; 
	unsigned short biBitCount; 
	unsigned int biCompression; 
	unsigned int biSizeImage; 
	int biXPelsPerMeter; 
	int biYPelsPerMeter;
	unsigned int biClrUsed; 
	unsigned int biClrImportant; 
}VN_BITMAPINFOHEADER; 

typedef struct tagVN_RGBQUAD
{
    unsigned char rgbBlue;
    unsigned char rgbGreen;
    unsigned char rgbRed;
    unsigned char rgbReserved;
}VN_RGBQUAD;

typedef struct tagVN_BITMAPINFO 
{ 
	VN_BITMAPINFOHEADER bmiHeader; 
}VN_BITMAPINFO; 

typedef struct   
{ 
	unsigned int ckid;
	unsigned int dwFlags;
	unsigned int dwChunkOffset;
	unsigned int dwChunkLength;
}VN_AVIINDEX;


typedef struct   
{ 
	unsigned short wFormatTag;   
	unsigned short nChannels;
	unsigned int nSamplesPerSec;
	unsigned int nAvgBytesPerSec;
	unsigned short nBlockAlign;
	unsigned short biSize;
}VN_WAVEFORMAT;


#endif