#ifndef _AVICONV_H
#define _AVICONV_H

void* aviConv_init(char* aviFileName);
int aviConv_addFrame(void* handle, unsigned char* pBuf, int bufLen);
int aviConv_free(void* handle);

#endif
