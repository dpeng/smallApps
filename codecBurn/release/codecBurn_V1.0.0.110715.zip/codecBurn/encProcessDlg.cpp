// EncodingProcessDlg.cpp : implementation file
//

#include "stdafx.h"
#include "codecBurn.h"
#include "encProcessDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEncProcessDlg dialog


CEncProcessDlg::CEncProcessDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEncProcessDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CEncProcessDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CEncProcessDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEncProcessDlg)
	DDX_Control(pDX, IDC_ENDCODINGFILE, m_encodingFile);
	DDX_Control(pDX, IDC_CLOSEPROCESSDLG, m_btnClose);
	DDX_Control(pDX, IDC_STATIC_PROCESS_INFO, m_processInfo);
	DDX_Control(pDX, IDC_ENCODING_PROCESS, m_progress);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CEncProcessDlg, CDialog)
	//{{AFX_MSG_MAP(CEncProcessDlg)
	ON_WM_TIMER()
	ON_WM_CLOSE()
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_CLOSEPROCESSDLG, OnCloseprocessdlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEncProcessDlg message handlers

BOOL CEncProcessDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_progress.SetRange(0, 1000);
	m_nPos = 0;
	m_progress.SetPos(m_nPos);
	m_processInfo.SetWindowText("000 / 1000");
	m_processInfoStr = _T("");
	SetTimer(1, 100, NULL);
	m_bEnd = FALSE;
	m_Brush.CreateSolidBrush(SYSTEM_BACKCOLOR);
	CreateSkin();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CEncProcessDlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if (nIDEvent == 1)
	{
		m_progress.SetPos(m_nPos);
		if (m_nPos >= 1000)
			m_bEnd = TRUE;
		m_processInfoStr.Format("%03d / 1000", m_nPos);
		m_processInfo.SetWindowText(m_processInfoStr);
	}
	CDialog::OnTimer(nIDEvent);
}

BOOL CEncProcessDlg::DestroyWindow() 
{
	// TODO: Add your specialized code here and/or call the base class
	m_bEnd = TRUE;
	return CDialog::DestroyWindow();
}

void CEncProcessDlg::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	m_bEnd = TRUE;
	CDialog::OnClose();
}

HBRUSH CEncProcessDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here

	//if( pWnd->GetDlgCtrlID() == IDC_STATIC_PROJ) 
	{
		pDC->SetBkMode(TRANSPARENT);
		return m_Brush;
	}
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CEncProcessDlg::OnCloseprocessdlg() 
{
	// TODO: Add your control notification handler code here
	m_bEnd = TRUE;
	//DeleteObject(m_Brush);
	CDialog::OnCancel();
}


void CEncProcessDlg::CreateSkin()
{
	m_titleBar.Create(CRect(0,0,520,25),this,
		IDB_COMONTITLE,IDB_COMONTITLE,
		IDB_COMONTITLE,IDB_COMONTITLE);
	m_titleBar.SetLabel("Encoding...");
	
	m_btnClose.SetSkin(IDB_EXITNORMAL, IDB_EXITDOWN, IDB_EXITOVER, 0, 0, 0, 0, 0, 0);
	m_btnClose.SetTextColor(SYSTEM_BTNCOLOR);
	m_btnClose.SizeToContent();
}
