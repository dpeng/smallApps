#include "stdafx.h"
#include "codecBurn.h"
#include "codecBurnDlg.h"
#include "Interface.h"
extern "C" 
{
	#include "avcodec.h"
	#include "avformat.h"
}

#include <string>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

	enum { IDD = IDD_ABOUTBOX };
	protected:
	virtual void DoDataExchange(CDataExchange* pDX); 

protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


UINT                                    WM_FILE_END			= WM_USER +122;
_VIDEO_ENCODE_TYPE_						gVideoEncodeType    = NULL_ENCODE;
void                                   *aviHandle           = NULL;
CFile                                  *SourceFile          = NULL;
CString									m_strEncFrom		= _T("");
CString									m_strEncTo			= _T("");
BOOL									binitEnc			= FALSE;

CCodecBurnDlg::CCodecBurnDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCodecBurnDlg::IDD, pParent)
{
	m_strPlayStateText = _T("");

	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CCodecBurnDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCodecBurnDlg)
	DDX_Control(pDX, IDC_STATIC_MAIN, m_staticMain);
	DDX_Control(pDX, IDC_PLAY_WINDOW, m_staticPlayWindow);
	DDX_Control(pDX, IDC_MAKEBGSMALL, m_btnMakeBgSmall);
	DDX_Control(pDX, IDC_MAKEBGBIG, m_btnMakeBgBig);
	DDX_Control(pDX, IDC_STOP, m_btnStop);
	DDX_Control(pDX, IDC_VOLUME, m_btnVolume);
	DDX_Control(pDX, IDC_SHOWABOUT, m_btnAbout);
	DDX_Control(pDX, IDC_TIMEINFO, m_btnInfo);
	DDX_Control(pDX, IDC_PLAY_PAUSE, m_btnPause);
	DDX_Control(pDX, IDC_GET_PIC, m_btnCapture);
	DDX_Control(pDX, IDC_PLAY, m_btnPlay);
	DDX_Control(pDX, IDC_PLAY_FAST, m_btnFast);
	DDX_Control(pDX, IDC_PLAY_SLOW, m_btnSlow);
	DDX_Control(pDX, IDC_MINSIZE, m_btnMin);
	DDX_Control(pDX, IDC_CLOSE, m_btnClose);
	DDX_Control(pDX, IDC_INIT_BURN, m_btnBurn);
	DDX_Control(pDX, IDC_VIDEOENC, m_btnConvert);
	DDX_Control(pDX, IDC_OPEN_FILE, m_btnOpenFile);
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_CONFIGURATION, m_btnConf);
}

BEGIN_MESSAGE_MAP(CCodecBurnDlg, CDialog)
	//{{AFX_MSG_MAP(CCodecBurnDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_OPEN_FILE, OnOpenFile)
	ON_BN_CLICKED(IDC_PLAY, OnPlay)
	ON_BN_CLICKED(IDC_STOP, OnStop)
	ON_BN_CLICKED(IDC_INIT_BURN, OnInitBurn)
	ON_BN_CLICKED(IDC_PLAY_PAUSE, OnPlayPause)
	ON_BN_CLICKED(IDC_GET_PIC, OnGetPic)
	ON_BN_CLICKED(IDC_PLAY_FAST, OnPlayFast)
	ON_BN_CLICKED(IDC_PLAY_SLOW, OnPlaySlow)
	ON_WM_TIMER()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_VIDEOENC, OnVideoenc)
	ON_BN_CLICKED(IDC_CLOSE, OnBtnClose)
	ON_BN_CLICKED(IDC_MINSIZE, OnMinsize)
	ON_BN_CLICKED(IDC_MAKEBGBIG, OnMakebgbig)
	ON_BN_CLICKED(IDC_SHOWABOUT, OnShowabout)
	ON_BN_CLICKED(IDC_VOLUME, OnVolume)
	ON_BN_CLICKED(IDC_MAKEBGSMALL, OnMakebgsmall)
	ON_WM_HSCROLL()
	ON_WM_LBUTTONDOWN()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_CONFIGURATION, /*&CCodecBurnDlg::*/OnBnClickedConfiguration)
END_MESSAGE_MAP()

BOOL CCodecBurnDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	//_CrtSetBreakAlloc(1167);
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	SetIcon(m_hIcon, TRUE);
	SetIcon(m_hIcon, FALSE);
	
	memset(&m_picData, 0, sizeof(m_picData));
	m_picData.nCapacity = 720*576*3/2;
	m_picData.buf = (char*)malloc(m_picData.nCapacity);
	if (m_picData.buf)
	{
		memset(m_picData.buf, 0, sizeof(m_picData.buf));
	} 
	else
	{
		return FALSE;
	}
	m_picData.isHasData = 0;
	m_nSpeed = 0;
	m_bPause = TRUE;
	m_bVolume = TRUE;
	m_lPort = 0;
	m_nPrePlayPos = 0;
	m_dwMaxFileTime = 0;
	m_dwTotalFrames = 0;
	m_dwDisplaySecond = 0;
	m_dwDisplayMinute = 0;
	m_dwDisplayHour = 0;
	gVideoEncodeType = MPEG1_ENCODE;
	m_bFullScreen = FALSE;
	m_bBgBig = FALSE;
	m_bAviFile = FALSE;
	m_lAviFileLen = 0;
	m_lCurAviFileLen = 0;
	m_strEncFrom = _T("");
	m_strEncTo = _T("");
	memset(m_fileNameFrom, 0, sizeof(m_fileNameFrom));
	m_index = 0;
	m_hStreamPraser = NULL;
	
	m_smallBg.LoadBitmap(IDB_BACKGROUND);
	m_bigBg.LoadBitmap(IDB_BIGBACKGROUND);
	m_main.LoadBitmap(IDB_MAIN);
	m_staticPlayWindow.SetBitmap(m_smallBg);
	m_staticMain.SetBitmap(m_main);
	VN_PLAY_PlaySound(m_lPort);
	
	m_enumState = State_Close;
	SourceFile = new CFile;
	
	av_register_all();
	CreateSkinBtn();
	CreateSkinSlider();
	CreateUserDialog();

	ShowWindow(TRUE);
	CenterWindow();
	GetDlgItem(IDC_PLAY_WINDOW)->GetWindowRect(&m_rcScreen);
	GetWindowPlacement(&m_OldWndpl);
	OnStop();
	SetTimer(3, 100, NULL);
	SetWindowText("vCam Media Central");
	return TRUE;
}

void CCodecBurnDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

void CCodecBurnDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this);

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
	this->UpdateWindow();
}

HCURSOR CCodecBurnDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CALLBACK DisplayCBFun(long nPort, char * pBuf ,long nSize, long nWidth, long nHeight, long nStamp, long nType,long nReceaved)
{
	CCodecBurnDlg* dlg = (CCodecBurnDlg*)nReceaved;

    if(nSize <= dlg->m_picData.nCapacity)
	{
		dlg->m_picData.nSize = nSize;
		dlg->m_picData.nWidth = nWidth;
		dlg->m_picData.nHeight = nHeight;
		dlg->m_picData.nType = nType;
		memcpy(dlg->m_picData.buf,pBuf,nSize);
		dlg->m_picData.isHasData = 1;
	}
}

void CALLBACK fileEndCallBack(DWORD nPort, DWORD pUser)
{
	CCodecBurnDlg* pDlg = (CCodecBurnDlg *)pUser;
	VN_PLAY_ResetBuffer(nPort, BUF_VIDEO_SRC);
	VN_PLAY_ResetBuffer(nPort, BUF_AUDIO_SRC);
	VN_PLAY_ResetBuffer(nPort, BUF_VIDEO_RENDER);
	VN_PLAY_ResetBuffer(nPort, BUF_AUDIO_RENDER);
	pDlg->OnStop();
}

void CALLBACK DecCBFun(long nPort, char * pBuf, long nSize, FRAME_INFO * pFrameInfo, long nReserved1, long nReserved2)
{
      if(gVideoEncodeType == AVI_ENCODE)
	    return;

	if (!binitEnc)
	{
		if (pFrameInfo->nWidth > 10 &&
			pFrameInfo->nHeight > 10)
		{
			BOOL bNTSC = FALSE;
			if (pFrameInfo->nFrameRate >= NTSC_FRAME_RATE/1000)
			{
				bNTSC = TRUE;
			}
// #ifdef _DEBUG
// 			if (pFrameInfo->nHeight == 480)
// 			{
// 				bNTSC = TRUE;
// 			}
// #endif
			CEncoderSingleton::instance()->m_bConverting = TRUE;
			CEncoderSingleton::instance()->avEncodeInit(m_strEncTo.GetBuffer(0), pFrameInfo->nWidth, pFrameInfo->nHeight, bNTSC);
			binitEnc = TRUE;
		}
		return;
	}
	if (!CEncoderSingleton::instance() || !CEncoderSingleton::instance()->m_bConverting)
		return;
	if ( pFrameInfo->nType == T_YV12 ) 
	{
		CEncoderSingleton::instance()->avEncode(TRUE, pBuf, pFrameInfo->nWidth, pFrameInfo->nHeight, nSize);
	}
	if (pFrameInfo->nType == T_AUDIO16)
	{
		CEncoderSingleton::instance()->avEncode(FALSE, pBuf, 0, 0, nSize);
	}
}

void CCodecBurnDlg::OnOpenFile() 
{
	CString tempfilename = _T("");
	CFileDialog FileChooser(TRUE, 
		NULL,
		NULL, 
		OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		_T("dav files(*.dav)|*.dav|avi Files (*.avi)|*.avi||"));
	
	if (FileChooser.DoModal()==IDOK)    tempfilename = FileChooser.GetPathName() ;
	else    return ;

	CString TmpStr = "";
	TmpStr = CConfigurationSingleton::instance()->m_util.getFileSuffix(tempfilename.GetBuffer(0));
	if ((TmpStr == "avi") || (TmpStr == "AVI"))
		m_bAviFile = TRUE;
	else
		m_bAviFile = FALSE;

	m_strPlayFileName = tempfilename;
	tempfilename = _T("");
	OnPlay();
}

void CCodecBurnDlg::closeFile() 
{
	OnStop();
	VN_PLAY_CloseFile(m_lPort);
	m_enumState = State_Close;
}

BOOL g_IndexCreated = FALSE;
void CALLBACK FileRefDone(DWORD nReserved,DWORD nUser)
{
	g_IndexCreated = TRUE;
}

void CCodecBurnDlg::OnPlay() 
{
	if (m_strPlayFileName.GetLength() < 5)
	{
		OnOpenFile();
	}

	if (m_enumState == State_Play || m_enumState == State_Pause)
	{
		OnStop();
	}
	VN_PLAY_SetFileRefCallBack(m_lPort, FileRefDone, (DWORD)this);
	VN_PLAY_SetFileEndCallBack(m_lPort, fileEndCallBack, (DWORD)this);
	VN_PLAY_SetDisplayCallBack(m_lPort, DisplayCBFun,(long)this);

	if(!(VN_PLAY_OpenFile(m_lPort, m_strPlayFileName.GetBuffer(0))))
	{
		m_strPlayFileName = _T("");
		CString strError = _T("");
		strError.Format("Open file failed");
		MessageBox(strError);
		return;
	}
	if (m_dlgVolume.m_bVolume)
	{
		VN_PLAY_PlaySound(m_lPort);
	}
	BOOL bRet = VN_PLAY_Play(m_lPort, m_staticPlayWindow.GetSafeHwnd());
 	if (!bRet)  return;

	m_bPause = FALSE;
	m_enumState = State_Play;
	m_nSpeed = 0;
	GetDlgItem(IDC_PLAY)->ModifyStyle(WS_VISIBLE, 0, 0);
	SetTimer(1, 100, NULL);
	ChangeBackground();
}

void CCodecBurnDlg::convertToMpeg1() 
{
	OnStop();
	SetVideoEncodeFileName(gVideoEncodeType);
	int totalTime = 0;
	while(!binitEnc)
	{
		totalTime += 10;
		if (totalTime >= 10000)
		{
			break;
		}
		Sleep(10);
	}
	SetTimer(2, 100, NULL);
}

void CCodecBurnDlg::OnStop() 
{
	KillTimer(1);
	KillTimer(2);
	VN_PLAY_StopSound();
	VN_PLAY_Stop(m_lPort);
	VN_PLAY_CloseFile(m_lPort);
	if (m_bFullScreen)
		ViewFullScreen();
	if(m_enumState == State_Pause)
		OnPlayPause();
	m_enumState = State_Stop;
	if(m_bBgBig)
		ChangeBackground();
	m_nSpeed = 0;
    m_bPause = TRUE;
	GetDlgItem(IDC_TIMEINFO)->SetWindowText("00:00:00 / 00:00:00");
	if(m_enumState == State_Encode && gVideoEncodeType == AVI_ENCODE)
	{
		gVideoEncodeType = NULL_ENCODE;		
		WQSP_Free(m_hStreamPraser);
		SourceFile->Close();
		aviConv_free(aviHandle);
	}
	if (m_enumState == State_Encode && 
		(gVideoEncodeType == MPEG1_ENCODE || gVideoEncodeType == MPEG4_ENCODE))
	{
		gVideoEncodeType = NULL_ENCODE;	
	}
	GetDlgItem(IDC_PLAY)->ModifyStyle(0, WS_VISIBLE, 0);
	m_playSlider.SetPos(0);
	if (m_dlgProcess)
	{
		m_dlgProcess.m_bEnd = FALSE;
		m_dlgProcess.m_nPos = 0;
		m_dlgProcess.ShowWindow(FALSE);
		this->EnableWindow(TRUE);
	}
	if (m_dlgBurn)
	{
		m_dlgBurn.m_nPos = 0;
		m_dlgBurn.ShowWindow(FALSE);
		this->EnableWindow(TRUE);
	}
	if(CEncoderSingleton::instance())
	{
		CEncoderSingleton::instance()->m_bConverting = FALSE;
		CEncoderSingleton::instance()->avEncodeFree();
	}
	g_IndexCreated = FALSE;
	Invalidate();
}

void CCodecBurnDlg::OnInitBurn()
{
	OnStop();
	convertAndBurnDvdVideo();
}

DWORD CCodecBurnDlg::convertDvdAndBurnProc(LPVOID pParam)  
{	
	CHAR fileNameto[99][260] = {0};
	CCodecBurnDlg* pThis = (CCodecBurnDlg*)pParam;
	for(int i = 0; i < pThis->m_index; i++)
	{
		m_strEncFrom = (char*)&(pThis->m_fileNameFrom[i][0]);
		CString fileSuffix = CConfigurationSingleton::instance()->m_util.getFileSuffix(m_strEncFrom);
		if (((fileSuffix == "mp4") || (fileSuffix == "MP4")) ||
			((fileSuffix == "vob") || (fileSuffix == "VOB")))
		{
			strcpy((char*)&fileNameto[i][0], m_strEncFrom.GetBuffer(0));
		} 
		else
		{
			m_strEncTo.Format("%s\\%s.mpeg", CConfigurationSingleton::instance()->m_strVideoName, CConfigurationSingleton::instance()->m_util.GetGUIDStr().GetBuffer(0));
			if ((m_strEncFrom.GetLength() < 5) || (m_strEncTo.GetLength() < 5))
			{
				AfxMessageBox("Parse Input/OutPut FileName error");
			}
			pThis->convertToMpeg1();
			if(CEncoderSingleton::instance())
			{
				CEncoderSingleton::instance()->m_bConverting = TRUE;
				while(CEncoderSingleton::instance()->m_bConverting)
					Sleep(10);
			}
			strcpy((char*)&fileNameto[i][0], m_strEncTo.GetBuffer(0));
		}
	}
	Sleep(200);
	if (pThis->m_dlgBurn)
	{
		memcpy(pThis->m_dlgBurn.m_fileName, &fileNameto, sizeof(fileNameto));
		pThis->m_dlgBurn.m_index = pThis->m_index;
		pThis->m_dlgBurn.ShowWindow(TRUE);
		pThis->EnableWindow(FALSE);
		pThis->m_dlgBurn.m_tmpDirName = CConfigurationSingleton::instance()->m_util.GetCurPath();
	}
	pThis->m_dlgBurn.Writedvd();
	return 0;
}

void CCodecBurnDlg::convertAndBurnDvdVideo() 
{
	CConvertToDvdDlg convertDlg;
	if (IDOK == convertDlg.DoModal())
	{
		gVideoEncodeType = MPEG1_ENCODE;
		m_index = 0;
		memset(m_fileNameFrom, 0, sizeof(m_fileNameFrom));
		m_index = convertDlg.m_index;
		memcpy(&m_fileNameFrom, convertDlg.m_fileNameFrom, sizeof(m_fileNameFrom));
		DWORD dw;
		CreateThread(NULL,0,CCodecBurnDlg::convertDvdAndBurnProc,this,0,&dw);
	}
}

void CCodecBurnDlg::OnPlayPause() 
{
	if (m_enumState == State_Play || m_enumState == State_Pause)
	{
		if (!m_bPause)
		{
			VN_PLAY_Pause(m_lPort, TRUE);
			m_enumState = State_Pause;
			m_btnPause.SetSkin(IDB_PAUSEPLAYNORMAL, IDB_PAUSEPLAYDOWN, IDB_PAUSEPLAYOVER, 0, 0, 0, 0, 0, 0);
			m_btnPause.SizeToContent();
		}
		else
		{
			VN_PLAY_Pause(m_lPort, FALSE);
			m_enumState = State_Play;
			m_btnPause.SetSkin(IDB_PAUSEPAUSENORMAL, IDB_PAUSEPAUSEDOWN, IDB_PAUSEPAUSEOVER, 0, 0, 0, 0, 0, 0);
			m_btnPause.SizeToContent();
		}
		m_bPause = !m_bPause;
	}
}

void CCodecBurnDlg::OnGetPic() 
{
	if (!m_bAviFile)
	{
		m_dwMaxFileTime = VN_PLAY_GetFileTime(m_lPort);
		if (m_dwMaxFileTime <= 1)    return;
	}
	if (m_enumState == State_Stop) return;

	if(m_picData.isHasData) GetPic(m_picData.buf,m_picData.nSize,m_picData.nWidth,m_picData.nHeight,m_picData.nType);
	else MessageBox("Do not has data in buffer current");
}

void CCodecBurnDlg::GetPic(char* pImage, DWORD nBufSize,long nWidth,long nHeight,long nType)
{
	SYSTEMTIME tmpTime;
	memset(&tmpTime, 0, sizeof(SYSTEMTIME));
	GetLocalTime(&tmpTime);
	CString str = _T("");
	str.Format("%s\\%d%02d%02d%02d%02d%02d%03d.bmp", CConfigurationSingleton::instance()->m_strPicName.GetBuffer(0), 
		tmpTime.wYear,
		tmpTime.wMonth,
		tmpTime.wDay,
		tmpTime.wHour,
		tmpTime.wMinute,
		tmpTime.wSecond,
		tmpTime.wMilliseconds);
	VN_PLAY_ConvertToBmpFile(pImage,nBufSize,nWidth,nHeight,nType,str.GetBuffer(0));
	CString tmpstr = _T("");
	tmpstr.Format("Picture saved as:\n%s", str);
	MessageBox(tmpstr);
}

void CCodecBurnDlg::OnPlayFast() 
{
	if (VN_PLAY_Fast(m_lPort))
	{
		m_nSpeed++;
	}
}

void CCodecBurnDlg::OnPlaySlow() 
{
	if (VN_PLAY_Slow(m_lPort))
	{
		m_nSpeed--;
	}
}


void CCodecBurnDlg::OnTimer(UINT nIDEvent) 
{
	m_dwMaxFileTime = VN_PLAY_GetFileTime(m_lPort);
	m_dwTotalFrames	= VN_PLAY_GetFileTotalFrames(m_lPort);
	if (nIDEvent == 1 && m_enumState == State_Play &&(!m_bAviFile || g_IndexCreated))
	{
		DWORD nCurrentTime = VN_PLAY_GetPlayedTime(m_lPort);
		DWORD nHour   = (nCurrentTime / 3600) % 24;
		DWORD nMinute = (nCurrentTime % 3600) / 60;
		DWORD nSecond = nCurrentTime % 60;		
		
		DWORD nCurrentFrame = VN_PLAY_GetCurrentFrameNum(m_lPort);
		
		m_dwDisplayHour		= m_dwMaxFileTime/3600;
		m_dwDisplayMinute   = (m_dwMaxFileTime % 3600) / 60;
		m_dwDisplaySecond   = m_dwMaxFileTime % 60;
		m_strPlayStateText.Format("%02d:%02d:%02d / %02d:%02d:%02d", 
                                                    nHour, 
                                                    nMinute, 
                                                    nSecond, 
                                                    m_dwDisplayHour,
                                                    m_dwDisplayMinute,
                                                    m_dwDisplaySecond);
		
		GetDlgItem(IDC_TIMEINFO)->SetWindowText(m_strPlayStateText);
		if(m_playSlider.m_bSetPlayPos)
		{
			DWORD nTime = (DWORD)(m_playSlider.m_fPlayPos * m_dwMaxFileTime * 1000);
			VN_PLAY_ResetBuffer(m_lPort, BUF_VIDEO_RENDER);
			VN_PLAY_ResetBuffer(m_lPort, BUF_AUDIO_RENDER);
			VN_PLAY_SetPlayedTimeEx(m_lPort,nTime);
			m_playSlider.m_bSetPlayPos = FALSE;
			m_playSlider.m_fPlayPos = 0.0;
		}
		if (m_dwMaxFileTime >= 2)
		{
			int nScrollPos = nCurrentTime * PLAYER_SLIDER_MAX / (m_dwMaxFileTime - 1);
			if (m_nPrePlayPos == nScrollPos)  return;
			m_playSlider.SetPos(nScrollPos);
			m_nPrePlayPos = nScrollPos;
		}
	}
	if (nIDEvent == 2 && m_enumState == State_Encode)
	{
		float nScrollPos = 0;
		if (!m_bAviFile || g_IndexCreated)
		{
			DWORD nCurrentFrame = VN_PLAY_GetCurrentFrameNum(m_lPort);
			nScrollPos = (float)(nCurrentFrame * PLAYER_SLIDER_MAX / (m_dwTotalFrames - 1));
		}
		else
		{
			nScrollPos = float(VN_PLAY_GetPlayPos(m_lPort) * PLAYER_SLIDER_MAX);
		}
		m_dlgProcess.m_nPos = (int)nScrollPos;
		if (m_dlgProcess.m_bEnd && CEncoderSingleton::instance())
		{
			CEncoderSingleton::instance()->m_bConverting = FALSE;
			OnStop();
		}
	}
	
	if (nIDEvent == 2 && gVideoEncodeType == AVI_ENCODE)
	{
		int nScrollPos = (int)(m_lCurAviFileLen * PLAYER_SLIDER_MAX / (m_lAviFileLen - 1));
		m_dlgProcess.m_nPos = nScrollPos;
		if (m_dlgProcess.m_bEnd)
		{
			OnStop();
		}
	}
	if (nIDEvent == 3 && m_dlgVolume.m_bVolumeChange)
	{
		m_dlgVolume.m_bVolumeChange = FALSE;
		if (m_dlgVolume.m_bVolume)
		{
			m_btnVolume.SetSkin(IDB_VOLUMEONNORMAL, IDB_VOLUMEONDOWN, IDB_VOLUMEONOVER, 0, 0, 0, 0, 0, 0);
			m_btnVolume.SizeToContent();
		} 
		else
		{
			m_btnVolume.SetSkin(IDB_VOLUMEOFFNORMAL, IDB_VOLUMEOFFDOWN, IDB_VOLUMEOFFOVER, 0, 0, 0, 0, 0, 0);
			m_btnVolume.SizeToContent();
		}
		m_btnVolume.Invalidate();
	}
	CDialog::OnTimer(nIDEvent);
}

void CCodecBurnDlg::SetVideoEncodeFileName(_VIDEO_ENCODE_TYPE_ videoType)
{	
	std::string filefullname = m_strEncTo;	
	std::string::size_type pos = 0 ;
	std::string::size_type idx = 0 ;
	char cDiskNum[4];
	memset(cDiskNum, 0, 4);
	idx = filefullname.find(":", pos);
	memcpy(cDiskNum, m_strEncTo, idx+1);
	unsigned __int64 iFreeBytes;
	GetDiskFreeSpaceEx(cDiskNum, (PULARGE_INTEGER)&iFreeBytes, NULL, NULL);

	if (iFreeBytes <= 1920*1080*5)  return;
    
	while ((idx = filefullname.find("\\", pos)) !=  std::string::npos)
	{
		CreateDirectory((filefullname.substr(0, idx)).c_str(), NULL) ;
		pos = idx + 1 ;
	}
	binitEnc = FALSE;
	if (videoType != AVI_ENCODE)
	{
		VN_PLAY_SetFileRefCallBack(m_lPort, FileRefDone, (DWORD)this);
		VN_PLAY_SetFileEndCallBack(m_lPort, fileEndCallBack, (DWORD)this);
		VN_PLAY_SetDecCallBack(m_lPort, DecCBFun);	
		VN_PLAY_OpenFile(m_lPort, m_strEncFrom.GetBuffer(0));
		VN_PLAY_Play(m_lPort, NULL);
		VN_PLAY_PlaySound(m_lPort);
	}
	else
	{
		VN_PLAY_OpenFile(m_lPort, m_strEncFrom.GetBuffer(0));
	}
	Sleep(10);
	m_enumState = State_Encode;
	if (m_dlgProcess)
	{
		m_dlgProcess.ShowWindow(TRUE);
		this->EnableWindow(FALSE);
	}
	CString tmpStr = _T("");
	tmpStr.Format("%s", m_strEncFrom.GetBuffer(0));
	m_dlgProcess.m_encodingFile.SetWindowText(tmpStr);
}

void CCodecBurnDlg::convertToMpeg4() 
{
	OnStop();
	SetVideoEncodeFileName(gVideoEncodeType);

	int totalTime = 0;
	while(!binitEnc)
	{
		totalTime += 10;
		if (totalTime >= 10000)
		{
			break;
		}
		Sleep(10);
	}

	SetTimer(2, 100, NULL);
	
}

void CCodecBurnDlg::ViewFullScreen() 
{
	m_bFullScreen = !m_bFullScreen;
	
	if(m_bFullScreen)
	{
		ModifyStyle(WS_SIZEBOX, 0, 0);
		
		GetDlgItem(IDC_OPEN_FILE)->ModifyStyle(WS_VISIBLE, 0, 0);
		GetDlgItem(IDC_PLAY)->ModifyStyle(WS_VISIBLE, 0, 0);
		GetDlgItem(IDC_PLAY_PAUSE)->ModifyStyle(WS_VISIBLE, 0, 0);
		GetDlgItem(IDC_PLAY_FAST)->ModifyStyle(WS_VISIBLE, 0, 0);
		GetDlgItem(IDC_PLAY_PAUSE)->ModifyStyle(WS_VISIBLE, 0, 0);
		GetDlgItem(IDC_PLAY_FAST)->ModifyStyle(WS_VISIBLE, 0, 0);
		GetDlgItem(IDC_PLAY_SLOW)->ModifyStyle(WS_VISIBLE, 0, 0);
		GetDlgItem(IDC_STOP)->ModifyStyle(WS_VISIBLE, 0, 0);
		GetDlgItem(IDC_GET_PIC)->ModifyStyle(WS_VISIBLE, 0, 0);
		GetDlgItem(IDC_VIDEOENC)->ModifyStyle(WS_VISIBLE, 0, 0);
		GetDlgItem(IDC_VOLUME)->ModifyStyle(WS_VISIBLE, 0, 0);
		GetDlgItem(IDC_MAKEBGBIG)->ModifyStyle(WS_VISIBLE, 0, 0);
		GetDlgItem(IDC_MAKEBGSMALL)->ModifyStyle(WS_VISIBLE, 0, 0);
        
		GetDlgItem(IDC_INIT_BURN)->ModifyStyle(WS_VISIBLE, 0, 0);	

		GetDlgItem(IDC_TIMEINFO)->ModifyStyle(WS_VISIBLE,0,0);
		
		CRect WindowRect, ClientRect;
		RECT FullScreenRect;
		
		GetWindowRect(&WindowRect);
		WindowRect.left+=1;
		WindowRect.right+=1;
		MoveWindow(CRect(0,0,352,288),TRUE);
		
		GetWindowRect(&WindowRect);
		GetClientRect(&ClientRect);
		ClientToScreen(&ClientRect);
		
		int x = GetSystemMetrics(SM_CXSCREEN);
		int y = GetSystemMetrics(SM_CYSCREEN);
		FullScreenRect.left = WindowRect.left - ClientRect.left;
		FullScreenRect.top = WindowRect.top - ClientRect.top;
		FullScreenRect.right = WindowRect.right - ClientRect.right + x;
		FullScreenRect.bottom = WindowRect.bottom - ClientRect.bottom + y;
		
		WINDOWPLACEMENT wndpl;
		wndpl.length = sizeof(WINDOWPLACEMENT);
		wndpl.flags = 0;
		wndpl.showCmd = SW_SHOWNORMAL;
		wndpl.rcNormalPosition = FullScreenRect;
		SetWindowPlacement(&wndpl);
		
		RECT rc;
		GetClientRect(&rc);
		GetDlgItem(IDC_PLAY_WINDOW)->MoveWindow(&rc,TRUE);
		this->RedrawWindow();
	}
	else
	{
		GetDlgItem(IDC_OPEN_FILE)->ModifyStyle(0,WS_VISIBLE,0);
		if (m_enumState != State_Play && m_enumState != State_Pause)
		{
			GetDlgItem(IDC_PLAY)->ModifyStyle(0,WS_VISIBLE,0);
		}
		GetDlgItem(IDC_PLAY_PAUSE)->ModifyStyle(0,WS_VISIBLE,0);
		GetDlgItem(IDC_PLAY_FAST)->ModifyStyle(0,WS_VISIBLE,0);
		GetDlgItem(IDC_PLAY_PAUSE)->ModifyStyle(0,WS_VISIBLE,0);
		GetDlgItem(IDC_PLAY_FAST)->ModifyStyle(0,WS_VISIBLE,0);
		GetDlgItem(IDC_PLAY_SLOW)->ModifyStyle(0,WS_VISIBLE,0);
		GetDlgItem(IDC_STOP)->ModifyStyle(0,WS_VISIBLE,0);
		GetDlgItem(IDC_GET_PIC)->ModifyStyle(0,WS_VISIBLE,0);
		GetDlgItem(IDC_VIDEOENC)->ModifyStyle(0, WS_VISIBLE, 0);
		GetDlgItem(IDC_VOLUME)->ModifyStyle(0, WS_VISIBLE, 0);
		GetDlgItem(IDC_MAKEBGBIG)->ModifyStyle(0, WS_VISIBLE, 0);
        
		GetDlgItem(IDC_INIT_BURN)->ModifyStyle(0,WS_VISIBLE,0);	

		GetDlgItem(IDC_TIMEINFO)->ModifyStyle(0,WS_VISIBLE,0);

		SetWindowPlacement(&m_OldWndpl);
		m_bBgBig = FALSE;
		ChangeBackground();
	}
}

void CCodecBurnDlg::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	CPoint dpoint;
	CRect  vwrect;
	GetCursorPos(&dpoint);	
	
	m_staticPlayWindow.GetWindowRect(&vwrect);
	if( ( m_enumState == State_Play || m_enumState == State_Pause) && vwrect.PtInRect(dpoint))
	{
		ViewFullScreen();
	}
	CDialog::OnLButtonDblClk(nFlags, point);
}

BOOL CCodecBurnDlg::PreTranslateMessage(MSG* pMsg)
{
	if ( pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN) 
		return TRUE;
	if ( pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_ESCAPE) 
	{
		if (m_bFullScreen)
			ViewFullScreen();
		return TRUE;
	}
	return CDialog::PreTranslateMessage(pMsg);
}


DWORD CCodecBurnDlg::convertToAviThreadProc(LPVOID pParam)  
{
	CCodecBurnDlg* pAvi = (CCodecBurnDlg*)pParam;
	
	const int BUFLEN  = 4096;
	BOOL ifFindIFrame = FALSE;
	unsigned char buf[BUFLEN];
	if(!SourceFile->Open(m_strEncFrom,CFile::modeRead|CFile::shareDenyNone))
		return -1;
    
	pAvi->m_lAviFileLen = SourceFile->GetLength();

	while(TRUE)
	{
		int len = SourceFile->Read(buf, BUFLEN);
		if (len <= 0) break;
        
		pAvi->m_lCurAviFileLen += len;
		WQSP_InputData(pAvi->m_hStreamPraser, buf, len);
		WQ_FRAME_INFO * frame=NULL;
		while (NULL!=(frame=WQSP_GetNextFrame(pAvi->m_hStreamPraser)))
		{
			if (0 == frame->nLength)    continue;
			
			if (0 == frame->nFrameLength)
			{
				ifFindIFrame = FALSE;
				continue;
			}
			
			if ((WQ_FRAME_TYPE_VIDEO==frame->nType) && (WQ_FRAME_TYPE_VIDEO_I_FRAME==frame->nSubType))
				ifFindIFrame = TRUE;
			
			if (!ifFindIFrame)  continue;
			
			aviConv_addFrame(aviHandle, frame->pHeader, frame->nLength);
			
		}
	}
	WQSP_Free(pAvi->m_hStreamPraser);
	SourceFile->Close();
	aviConv_free(aviHandle);
	return 1;
}

void CCodecBurnDlg::convertToAvi() 
{
	OnStop();
	SetVideoEncodeFileName(gVideoEncodeType);
	m_dwMaxFileTime = VN_PLAY_GetFileTime(m_lPort);
	m_dwTotalFrames	= VN_PLAY_GetFileTotalFrames(m_lPort);
	if (m_dwMaxFileTime <= 1)   return;
    	
	SetTimer(2, 100, NULL);
	
	m_hStreamPraser = WQSP_Init();
	if (m_hStreamPraser == NULL)    return;
	
	aviHandle = aviConv_init(m_strEncTo.GetBuffer(0));
	if (aviHandle == 0) return;
	DWORD dw;
	CreateThread(NULL,0,CCodecBurnDlg::convertToAviThreadProc,this,0,&dw);
}

void CCodecBurnDlg::OnClose() 
{
	closeFile();
	if (m_dlgProcess)
	{
		DeleteObject(m_dlgProcess.m_Brush);
		m_dlgProcess.DestroyWindow();
	}
	if (m_dlgBurn)
	{
		DeleteObject(m_dlgBurn.m_Brush);
		m_dlgBurn.DestroyWindow();
	}
	free(m_picData.buf);
	m_picData.buf = NULL;
    memset(&m_picData, 0, sizeof(capturePicData));
	SAFE_DELETE(SourceFile);
	CDialog::OnClose();
}
void CCodecBurnDlg::CreateSkinBtn()
{
    m_btnOpenFile.SetSkin(IDB_OPENFILENORMAL, IDB_OPENFILEDOWN, IDB_OPENFILEOVER, 0, 0, 0, 0, 0, 0);
	m_btnOpenFile.SizeToContent();
	m_btnConvert.SetSkin(IDB_CONVERTNORMAL, IDB_CONVERTDOWN, IDB_CONVERTOVER, 0, 0, 0, 0, 0, 0);
	m_btnConvert.SizeToContent();
	m_btnBurn.SetSkin(IDB_BURNNORMAL, IDB_BURNDOWN, IDB_BURNOVER, 0, 0, 0, 0, 0, 0);
	m_btnBurn.SizeToContent();
	m_btnClose.SetSkin(IDB_EXITNORMAL, IDB_EXITDOWN, IDB_EXITOVER, 0, 0, 0, 0, 0, 0);
	m_btnClose.SizeToContent();
	m_btnMin.SetSkin(IDB_MINNORMAL, IDB_MINIDOWN, IDB_MINIOVER, 0, 0, 0, 0, 0, 0);
	m_btnMin.SizeToContent();
	m_btnSlow.SetSkin(IDB_BACKNORMAL, IDB_BACKDOWN, IDB_BACKOVER, 0, 0, 0, 0, 0, 0);
	m_btnSlow.SizeToContent();
	m_btnFast.SetSkin(IDB_FORWARDNORMAL, IDB_FORWARDDOWN, IDB_FORWARDOVER, 0, 0, 0, 0, 0, 0);
	m_btnFast.SizeToContent();
	m_btnPlay.SetSkin(IDB_PLAYNORMAL, IDB_PLAYDOWN, IDB_PLAYOVER, 0, 0, 0, 0, 0, 0);
	m_btnPlay.SizeToContent();
	m_btnCapture.SetSkin(IDB_CAPTURENORMAL, IDB_CAPTUREDOWN, IDB_CAPTUREOVER, 0, 0, 0, 0, 0, 0);
	m_btnCapture.SizeToContent();
	m_btnPause.SetSkin(IDB_PAUSEPAUSENORMAL, IDB_PAUSEPAUSEDOWN, IDB_PAUSEPAUSEOVER, 0, 0, 0, 0, 0, 0);
	m_btnPause.SizeToContent();
	m_btnInfo.SetSkin(IDB_TIMEINFO, IDB_TIMEINFO, IDB_TIMEINFO, 0, 0, 0, 0, 0, 0);
	m_btnInfo.SizeToContent();
	m_btnAbout.SetSkin(IDB_ABOUTNORMAL, IDB_ABOUTDOWN, IDB_ABOUTOVER, 0, 0, 0, 0, 0, 0);
	m_btnAbout.SizeToContent();
	m_btnVolume.SetSkin(IDB_VOLUMEONNORMAL, IDB_VOLUMEONDOWN, IDB_VOLUMEONOVER, 0, 0, 0, 0, 0, 0);
	m_btnVolume.SizeToContent();
	m_btnStop.SetSkin(IDB_STOPNORMAL, IDB_STOPDOWN, IDB_STOPOVER, 0, 0, 0, 0, 0, 0);
	m_btnStop.SizeToContent();
	m_btnMakeBgSmall.SetSkin(IDB_MAKEBGSMALLNORMAL, IDB_MAKEBGSMALLDOWN, IDB_MAKEBGSMALLOVER, 0, 0, 0, 0, 0, 0);
	m_btnMakeBgSmall.SizeToContent();
	m_btnMakeBgBig.SetSkin(IDB_MAKEBGBIGNORMAL, IDB_MAKEBGBIGDOWN, IDB_MAKEBGBIGOVER, 0, 0, 0, 0, 0, 0);
	m_btnMakeBgBig.SizeToContent();
	m_btnConf.SetSkin(IDB_SETNORMAL, IDB_SETDOWN, IDB_SETOVER, 0, 0, 0, 0, 0, 0);
	m_btnConf.SizeToContent();
	GetDlgItem(IDC_MAKEBGSMALL)->ModifyStyle(WS_VISIBLE, 0, 0);
}

void CCodecBurnDlg::CreateSkinSlider()
{
	m_playSlider.Create(CRect(97,578,480,690),this,
		IDB_PLAYSLIDER,IDB_PLAYSLIDERBASE,
		IDB_PLAYSLIDEROVER,IDB_PLAYSLIDERBTN);
	m_playSlider.ResetSlider();

	m_titleBar.Create(CRect(0,0,720,68),this,
		IDB_MAIN,IDB_MAIN,
		IDB_MAIN,IDB_MAIN);
}

void CCodecBurnDlg::CreateUserDialog()
{
	m_dlgProcess.Create(IDD_CODEC_PROCESS, NULL);
	m_dlgProcess.CenterWindow();
	m_dlgProcess.ShowWindow(FALSE);

	m_dlgBurn.Create(IDD_BURN_DVD_VIDEO, NULL);
	m_dlgBurn.CenterWindow();
	m_dlgBurn.ShowWindow(FALSE);

	m_dlgVolume.Create(IDD_VOLUME, NULL);
	m_dlgVolume.ShowWindow(FALSE);

	CConfigurationSingleton::instance()->Create(IDD_CONFIGURATION, NULL);
	CConfigurationSingleton::instance()->CenterWindow();
	CConfigurationSingleton::instance()->ShowWindow(FALSE);
}

void CCodecBurnDlg::OnVideoenc() 
{
	CEncTypeDlg encTypeDlg;
	if (IDOK == encTypeDlg.DoModal())
	{
		gVideoEncodeType = encTypeDlg.m_encType;
		m_strEncFrom = encTypeDlg.m_strFromFile;
		m_strEncTo = encTypeDlg.m_strToFile;
		m_bAviFile = encTypeDlg.m_bAviFile;

		switch(gVideoEncodeType)
		{
		case NULL_ENCODE:
			break;
		case MPEG1_ENCODE:
			convertToMpeg1();
			break;
		case MPEG4_ENCODE:
			convertToMpeg4();
			break;
		case AVI_ENCODE:
			convertToAvi();
			break;
		default:
			break;
		}
	}
}

void CCodecBurnDlg::OnBtnClose()
{
	OnClose();
	exit(0);
}

void CCodecBurnDlg::OnMinsize() 
{
	ShowWindow(SW_SHOWMINIMIZED); 
}

void CCodecBurnDlg::ChangeBackground()
{
	RECT rc = { 0, 57, 0, 0 };
	if (!m_bBgBig)
	{
		rc.right  = (long)((m_rcScreen.right - m_rcScreen.left) * 1.34);
		rc.bottom = m_rcScreen.bottom - m_rcScreen.top;
		m_staticPlayWindow.MoveWindow(&rc, TRUE);
		m_staticPlayWindow.SetBitmap(m_bigBg);
		GetDlgItem(IDC_OPEN_FILE)->ModifyStyle(WS_VISIBLE, 0, 0);
		GetDlgItem(IDC_PLAY)->ModifyStyle(WS_VISIBLE, 0, 0);
		GetDlgItem(IDC_VIDEOENC)->ModifyStyle(WS_VISIBLE, 0, 0);
		GetDlgItem(IDC_INIT_BURN)->ModifyStyle(WS_VISIBLE, 0, 0);
		GetDlgItem(IDC_MAKEBGBIG)->ModifyStyle(WS_VISIBLE, 0, 0);
		GetDlgItem(IDC_MAKEBGSMALL)->ModifyStyle(0, WS_VISIBLE, 0);
	}
	else
	{
		rc.right = m_rcScreen.right - m_rcScreen.left;
		rc.bottom = m_rcScreen.bottom - m_rcScreen.top + 57;
		m_staticPlayWindow.MoveWindow(&rc, TRUE);
		m_staticPlayWindow.SetBitmap(m_smallBg);
		GetDlgItem(IDC_OPEN_FILE)->ModifyStyle(0, WS_VISIBLE, 0);
		GetDlgItem(IDC_PLAY)->ModifyStyle(WS_VISIBLE, 0, 0);
		GetDlgItem(IDC_VIDEOENC)->ModifyStyle(0, WS_VISIBLE, 0);
		GetDlgItem(IDC_INIT_BURN)->ModifyStyle(0, WS_VISIBLE, 0);
		GetDlgItem(IDC_MAKEBGBIG)->ModifyStyle(0, WS_VISIBLE, 0);
		GetDlgItem(IDC_MAKEBGSMALL)->ModifyStyle(WS_VISIBLE, 0, 0);
	}
	m_bBgBig = !m_bBgBig;
	this->RedrawWindow();
}
void CCodecBurnDlg::OnMakebgbig() 
{
	if ((m_enumState != State_Play) && (m_enumState != State_Pause))
		return;
	ChangeBackground();
}

void CCodecBurnDlg::OnMakebgsmall() 
{
	ChangeBackground();
}

void CCodecBurnDlg::OnShowabout() 
{
	CAboutDlg dlg;
	dlg.DoModal();
}

void CCodecBurnDlg::OnVolume() 
{
	m_bVolume = !m_bVolume;
	if (!m_bVolume)
	{
		m_dlgVolume.m_softVolume.SetPos(100 - (VN_PLAY_GetVolume(0)*100/MAX_VOLUME));
		CRect rc;
		this->GetWindowRect(&rc);
		m_dlgVolume.MoveWindow(CRect(CPoint(rc.right-45, rc.bottom-190),CSize(40,160)), TRUE);
		m_dlgVolume.ShowWindow(TRUE);
	}
	else
	{
		m_dlgVolume.ShowWindow(FALSE);
	}
}
void CCodecBurnDlg::OnBnClickedConfiguration()
{
	OnStop();
	CConfigurationSingleton::instance()->ShowWindow(TRUE);
	this->EnableWindow(FALSE);
}
