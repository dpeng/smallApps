#pragma once
#include "afxwin.h"
#include "xskinbutton.h"
#include "afxcmn.h"
#include "vnplayer.h"
#include <mmsystem.h>
#include "codecBurn.h"

#define MAX_VOLUME 0xFFFF

class CVolumeDlg : public CDialog
{
	DECLARE_DYNAMIC(CVolumeDlg)

public:
	CVolumeDlg(CWnd* pParent = NULL);
	virtual ~CVolumeDlg();
	enum { IDD = IDD_VOLUME };
	afx_msg void OnBnClickedBtnvolume();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
#ifdef SYSTEM_VOLUME
	BOOL amdUninitialize();
	BOOL amdInitialize();
	BOOL amdGetMasterVolumeControl();
	BOOL amdGetMasterMuteControl();
	BOOL amdGetMasterVolumeValue(DWORD &dwVal) const;
	BOOL amdSetMasterVolumeValue(DWORD dwVal) const;
	BOOL amdGetMasterMuteValue(LONG &lVal) const;
	BOOL amdSetMasterMuteValue(LONG lVal) const;
#endif
	CxSkinButton		m_btnMyVolume;
	BOOL				m_bVolume;
	CBrush				m_Brush;
	CSliderCtrl			m_softVolume;
	BOOL				m_bVolumeChange;
#ifdef SYSTEM_VOLUME
	CSliderCtrl			m_systemVolume;
#endif
	DWORD				m_dwVal;
	BOOL				m_bMute;
	UINT				m_nNumMixers;
	HMIXER				m_hMixer;
	MIXERCAPS			m_mxcaps;

	DWORD				m_dwMinimum;
	DWORD				m_dwMaximum;
	DWORD				m_dwVolumeControlID;
	DWORD				m_dwMuteControlID;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
};
