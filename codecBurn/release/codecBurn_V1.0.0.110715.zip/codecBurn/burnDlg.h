#if !defined(__BURN_DLG_H__)
#define __BURN_DLG_H__

#if _MSC_VER > 1000
#pragma once
#endif

#include "xskinbutton.h"
#include "titleBar.h"

class CBurnDlg : public CDialog
{
public:
	CBurnDlg(CWnd* pParent = NULL);
	CBrush m_Brush;
	CHAR m_fileName[99][260];
	int m_index;
	void Writedvd();
	DWORD m_nPos;
	CString m_tmpDirName;

protected:

	virtual void DoDataExchange(CDataExchange* pDX);
	afx_msg void StopWrite();
	virtual BOOL OnInitDialog();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnLoad();
	afx_msg void OnUnload();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnCloseburndlg();

	DECLARE_MESSAGE_MAP()
private:
	static DWORD  WINAPI WriteDVDVideoPro(LPVOID lpParam);
	void CreateSkin();
	enum { IDD = IDD_BURN_DVD_VIDEO };
	CxSkinButton	m_btnClose;
	CProgressCtrl	m_dvdBurnProgress;
	CStatic			m_info;
	CTitleBase		m_titleBar;
	CString			m_infoStr;	
};

#endif