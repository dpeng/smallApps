#if !defined(_CONVERT_TO_DVD_H_)
#define _CONVERT_TO_DVD_H_

#if _MSC_VER > 1000
#pragma once
#endif

#include "xskinbutton.h"
#include "titleBar.h"
#include "Util.h"
#include "afxwin.h"

#define MAX_FILE_ONCE_OPEN 100*MAX_PATH
class CConvertToDvdDlg : public CDialog
{
public:
	CConvertToDvdDlg(CWnd* pParent = NULL);

	enum { IDD = IDD_CONVERTTODVD };
	afx_msg void OnCbnSelchangeCdromdevicelist();
	CBrush m_Brush;	
	CHAR m_fileNameFrom[99][260];
	int m_index;
	char m_DeviceCh;
	BOOL m_bCoverDisk;

	protected:
		virtual void DoDataExchange(CDataExchange* pDX);
		afx_msg void OnCloseconverttodvddlg();
		virtual BOOL OnInitDialog();
		afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
		afx_msg void OnAddfile();
		afx_msg void OnDeletefile();
		afx_msg void OnDeleteall();
		virtual void OnOK();
		virtual void OnCancel();
		DECLARE_MESSAGE_MAP()

	private:		
		void CreateSkin();
		void initDivice();
		BOOL StartDVDDevice();
		CTitleBase		m_titleBar;
		BOOL			m_bContinue;
		CComboBox		m_devList;
		CListCtrl		m_lstFile;
		CxSkinButton	m_btnDeleteFile;
		CxSkinButton	m_btnDeleteAllFiles;
		CxSkinButton	m_btnAddFile;
		CxSkinButton	m_btnOk;
		CxSkinButton	m_btnCancel;
		CxSkinButton	m_btnClose;
};
#endif