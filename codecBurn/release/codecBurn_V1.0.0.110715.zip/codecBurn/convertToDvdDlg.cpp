// ConvertToDvd.cpp : implementation file
//

#include "stdafx.h"
#include "codecBurn.h"
#include "convertToDvdDlg.h"
#include <list>
#include "Interface.h"
#include "Configuration.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CConvertToDvdDlg dialog


CConvertToDvdDlg::CConvertToDvdDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CConvertToDvdDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CConvertToDvdDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CConvertToDvdDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CConvertToDvdDlg)
	DDX_Control(pDX, IDC_FILELIST, m_lstFile);
	DDX_Control(pDX, IDC_DELETEFILE, m_btnDeleteFile);
	DDX_Control(pDX, IDC_DELETEALL, m_btnDeleteAllFiles);
	DDX_Control(pDX, IDC_ADDFILE, m_btnAddFile);
	DDX_Control(pDX, IDOK, m_btnOk);
	DDX_Control(pDX, IDCANCEL, m_btnCancel);
	DDX_Control(pDX, IDC_CLOSECONVERTTODVDDLG, m_btnClose);
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_CDROMDEVICELIST, m_devList);
}


BEGIN_MESSAGE_MAP(CConvertToDvdDlg, CDialog)
	//{{AFX_MSG_MAP(CConvertToDvdDlg)
	ON_BN_CLICKED(IDC_CLOSECONVERTTODVDDLG, OnCloseconverttodvddlg)
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_ADDFILE, OnAddfile)
	ON_BN_CLICKED(IDC_DELETEFILE, OnDeletefile)
	ON_BN_CLICKED(IDC_DELETEALL, OnDeleteall)
	//}}AFX_MSG_MAP
	ON_CBN_SELCHANGE(IDC_CDROMDEVICELIST, /*&CConvertToDvdDlg::*/OnCbnSelchangeCdromdevicelist)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CConvertToDvdDlg message handlers

void CConvertToDvdDlg::OnCloseconverttodvddlg() 
{
	// TODO: Add your control notification handler code here
	DeleteObject(m_Brush);
	CConvertToDvdDlg::OnCancel();
}

void CConvertToDvdDlg::CreateSkin()
{
	m_titleBar.Create(CRect(0,0,520,25),this,
		IDB_COMONTITLE,IDB_COMONTITLE,
		IDB_COMONTITLE,IDB_COMONTITLE);
	m_titleBar.SetLabel("Burn DVD");
	
	m_btnClose.SetSkin(IDB_EXITNORMAL, IDB_EXITDOWN, IDB_EXITOVER, 0, 0, 0, 0, 0, 0);
	m_btnClose.SetTextColor(SYSTEM_BTNCOLOR);
	m_btnClose.SizeToContent();
	
    m_btnOk.SetSkin(IDB_COMONBTNNORMAL, IDB_COMONBTNDOWN, IDB_COMONBTNOVER, 0, 0, 0, 0, 0, 0);
	m_btnOk.SetTextColor(SYSTEM_BTNCOLOR);
	m_btnOk.SizeToContent();
	
    m_btnCancel.SetSkin(IDB_COMONBTNNORMAL, IDB_COMONBTNDOWN, IDB_COMONBTNOVER, 0, 0, 0, 0, 0, 0);
	m_btnCancel.SetTextColor(SYSTEM_BTNCOLOR);
	m_btnCancel.SizeToContent();
	
    m_btnDeleteFile.SetSkin(IDB_COMONBTNNORMAL, IDB_COMONBTNDOWN, IDB_COMONBTNOVER, 0, 0, 0, 0, 0, 0);
	m_btnDeleteFile.SetTextColor(SYSTEM_BTNCOLOR);
	m_btnDeleteFile.SizeToContent();
	
    m_btnDeleteAllFiles.SetSkin(IDB_COMONBTNNORMAL, IDB_COMONBTNDOWN, IDB_COMONBTNOVER, 0, 0, 0, 0, 0, 0);
	m_btnDeleteAllFiles.SetTextColor(SYSTEM_BTNCOLOR);
	m_btnDeleteAllFiles.SizeToContent();
	
    m_btnAddFile.SetSkin(IDB_COMONBTNNORMAL, IDB_COMONBTNDOWN, IDB_COMONBTNOVER, 0, 0, 0, 0, 0, 0);
	m_btnAddFile.SetTextColor(SYSTEM_BTNCOLOR);
	m_btnAddFile.SizeToContent();
}

BOOL CConvertToDvdDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_lstFile.InsertColumn(0, "fileName", LVCFMT_LEFT, 358);
	m_Brush.CreateSolidBrush(SYSTEM_BACKCOLOR);
	CreateSkin();
	memset(m_fileNameFrom, 0, sizeof(m_fileNameFrom));
	m_index = 0;
	m_bCoverDisk = FALSE;
	m_bContinue = FALSE;
	initDivice();
	return TRUE;
}

HBRUSH CConvertToDvdDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	pDC->SetBkMode(TRANSPARENT);
	return m_Brush;
	return hbr;
}

void CConvertToDvdDlg::OnAddfile() 
{
	CString FileName = _T("");
	CFileDialog FileChooser(TRUE, 
		NULL,
		NULL, 
		OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_ALLOWMULTISELECT,
		"dav Files (*.dav)|*.dav|avi Files (*.avi)|*.avi|mp4 Files (*.mp4)|*.mp4||");
	FileChooser.m_ofn.nMaxFile = MAX_FILE_ONCE_OPEN; 
	char* pc = new char[MAX_FILE_ONCE_OPEN]; 
	FileChooser.m_ofn.lpstrFile = pc; 
	FileChooser.m_ofn.lpstrFile[0] = NULL;

	if (IDOK == FileChooser.DoModal())
	{
		POSITION pos;
		pos=FileChooser.GetStartPosition();
		while (pos!=NULL)
		{
			FileName = FileChooser.GetNextPathName(pos);
			CString fileSuffix = CConfigurationSingleton::instance()->m_util.getFileSuffix(FileName);
			if ( (fileSuffix != "dav") && (fileSuffix != "DAV")  &&
				 (fileSuffix != "avi") && (fileSuffix != "AVI")  &&
				 (fileSuffix != "mp4") && (fileSuffix != "MP4"))
			{
				fileSuffix.Format("%s\nMaybe Not Support, Continue ?",FileName);
				if (MessageBox(fileSuffix, "confirm", MB_ICONQUESTION | MB_YESNO) != IDYES)
					return;
			}
			
			int index = m_lstFile.GetItemCount();
			m_lstFile.InsertItem(index, FileName);
		}
	}
	SAFE_DELETE(pc);
}

void CConvertToDvdDlg::OnDeletefile() 
{
	POSITION pos = m_lstFile.GetFirstSelectedItemPosition();
	if (pos == NULL)
		return;
	int nItem = m_lstFile.GetNextSelectedItem(pos);
	CString tmpStr = m_lstFile.GetItemText(nItem, 0);
	CString fileSuffix = CConfigurationSingleton::instance()->m_util.getFileSuffix(tmpStr);
	if ((fileSuffix == "vob") || (fileSuffix == "VOB"))
	{
		MessageBox("You already choose preserver this file which will copy from disk!");
		return;
	}
	m_lstFile.DeleteItem(nItem);
}

void CConvertToDvdDlg::OnDeleteall() 
{
	//m_lstFile.DeleteAllItems();	
	int num = m_lstFile.GetItemCount();
	if (num <= 0)
		return;
	for(int i = num - 1; i >= 0; i--)
	{
		CString tmpStr = m_lstFile.GetItemText(i, 0);
		CString fileSuffix = CConfigurationSingleton::instance()->m_util.getFileSuffix(tmpStr);
		if ((fileSuffix != "vob") && (fileSuffix != "VOB"))
			m_lstFile.DeleteItem(i);
	}
}

void CConvertToDvdDlg::OnOK() 
{
	if (!StartDVDDevice())
	{
		return;
	}
	m_index = m_lstFile.GetItemCount();
	if (m_index <= 0)
	{
		MessageBox("Please choose file to burn!");
		return;
	}
	for(int i = 0; i < m_index; i++)
		strcpy((char*)&m_fileNameFrom[i][0], m_lstFile.GetItemText(i, 0));
	CDialog::OnOK();
}

void CConvertToDvdDlg::OnCancel() 
{
	CDialog::OnCancel();
}

void CConvertToDvdDlg::OnCbnSelchangeCdromdevicelist()
{
	UpdateData(TRUE);
	StartDVDDevice();
}

void CConvertToDvdDlg::initDivice()
{
	if(CBurnInterface::LoadSDKDLL() == 0)
	{
		MessageBox("initDivice::load sdk failed!", "burnsdkErr", IDYES);
		return;
	}
	unsigned long dwDrives = GetLogicalDrives();
	unsigned long dwType = 0;
	char buf[32] = {0};

	m_devList.ResetContent();
	for (unsigned char nDrive=0; nDrive < 26; nDrive++)
	{
		if (!(dwDrives & (1 << nDrive)))
			continue;

		memset(buf,0,32);
		sprintf(buf,"%c",nDrive + 'A');
		strcat(buf,":\\");
		dwType = GetDriveType(buf);
		if (dwType != DRIVE_CDROM)
			continue;	

		if(CBurnInterface::SetDevice(nDrive) != 1)
			continue;

		BOOL IsTaoSupported,IsDaoSupported,IsSaoSupported;
		CBurnInterface::GetSupportedWriteModes(&IsTaoSupported, &IsDaoSupported, &IsSaoSupported);
		if(!IsTaoSupported || !IsDaoSupported || !IsSaoSupported)
			continue;

		unsigned char VendorNamePtr[32] = {0};
		unsigned char ProductNamePtr[32] = {0};

		CBurnInterface::GetVendorProductStrings(VendorNamePtr, ProductNamePtr);
		CString ss;
		ss.Format("%s%s", VendorNamePtr, ProductNamePtr);

		char _DevCh = 'A'+nDrive;
		CString str1;
		str1.Format("%c: ", _DevCh);

		ss = str1 + ss;

		m_devList.AddString(ss);
	}
	if (m_devList.GetCount() > 0)
	{
		m_devList.SetCurSel(0);
		StartDVDDevice();
	}
}

BOOL CConvertToDvdDlg::StartDVDDevice()
{
	if (m_devList.GetCount() == 0)
	{
		MessageBox("No Avliable CD-ROM");
		return FALSE;
	}
	CString tmpStr = _T("");
	m_devList.GetWindowText(tmpStr);
	char ch = tmpStr[0];

	if(CBurnInterface::SetDevice(ch - 'A') != 1)
	{
		MessageBox("Start CD-ROM failed, Please try later!");
		return FALSE;
	}
	m_DeviceCh = ch;


	BOOL IsDiscBlank = FALSE;
	BOOL IsDiscWriteable = FALSE;
	INT  DiscType = 0;	
	__int64 DiscRemainCapability = 0;

	CBurnInterface::GetDiscInfoEx(&IsDiscBlank, &IsDiscWriteable, &DiscType, &DiscRemainCapability);
	
	CString sDiskType;
	switch(DiscType){
	case 0x0008: sDiskType = "CD-ROM"; break;
	case 0x0009: sDiskType = "CD-R"; break;
	case 0x000A: sDiskType = "CD-RW"; break;
	case 0x0010: sDiskType = "DVD-ROM"; break;
	case 0x0011: sDiskType = "DVD-R"; break;
	case 0x0012: sDiskType = "DVD-RAM"; break;
	case 0x1314: sDiskType = "DVD-RW"; break;
	case 0x0013: sDiskType = "DVD-RW"; break;
	case 0x0014: sDiskType = "DVD-RW"; break;
	case 0x0015: sDiskType = "DVD-R DL"; break;
	case 0x0016: sDiskType = "DVD-R DL"; break;
	case 0x0017: sDiskType = "DVD-RW DL"; break;
	case 0x001A: sDiskType = "DVD+RW"; break;
	case 0x001B: sDiskType = "DVD+R"; break;
	case 0x0020: sDiskType = "DDCD-ROM"; break;
	case 0x0021: sDiskType = "DDCD-R"; break;
	case 0x0022: sDiskType = "DDCD-RW"; break;
	case 0x002A: sDiskType = "DVD+RW DL"; break;
	case 0x002B: sDiskType = "DVD+R DL"; break;	
	case 0x0040: sDiskType = "BD-ROM"; break;
	case 0x0041: sDiskType = "BD-R"; break;
	case 0x0042: sDiskType = "BD-R"; break;
	case 0x0043: sDiskType = "BD-RE"; break;
	case 0x0050: sDiskType = "HD-ROM"; break;
	case 0x0051: sDiskType = "HD-R"; break;
	case 0x0052: sDiskType = "HD-RAM"; break;
	case 0x0053: sDiskType = "HD-RW"; break;
	case 0x0058: sDiskType = "HD-R DL"; break;
	case 0x005A: sDiskType = "HD-RW DL"; break;

	default:sDiskType = "Unknown disk type";	
	}

	tmpStr.Format("Blank disk: %d  Writeable: %d  Capability: %d  ",
		IsDiscBlank,
		IsDiscWriteable,
		DiscRemainCapability);
	tmpStr = tmpStr + "Disk type: " + sDiskType;
	GetDlgItem(IDC_STATIC_INFO)->SetWindowText(tmpStr);
	return TRUE;
}