
#include "stdafx.h"
#include "codecBurn.h"
#include "burnDlg.h"
#include "Interface.h"
#include "Configuration.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CBurnDlg::CBurnDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CBurnDlg::IDD, pParent)
{
}


void CBurnDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CBurnDlg)
	DDX_Control(pDX, IDC_CLOSEBURNDLG, m_btnClose);
	DDX_Control(pDX, IDC_DVD_BURN_PROGRESS, m_dvdBurnProgress);
	DDX_Control(pDX, IDC_STATIC_INFO, m_info);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CBurnDlg, CDialog)
	//{{AFX_MSG_MAP(CBurnDlg)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_LOAD, OnLoad)
	ON_BN_CLICKED(IDC_UNLOAD, OnUnload)
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_CLOSEBURNDLG, OnCloseburndlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CBurnDlg::Writedvd() 
{
	if(!CBurnInterface::JudgeDisc())
	{
		OnCloseburndlg();
		return;
	}
	SetTimer(1,100,NULL);
	
	DWORD dwThreadID;
	::CreateThread(NULL,0,WriteDVDVideoPro,this,0,&dwThreadID);
}

void CBurnDlg::StopWrite() 
{
	KillTimer(1);
	CBurnInterface::AbortWrite();	
}

BOOL CBurnDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	m_Brush.CreateSolidBrush(SYSTEM_BACKCOLOR);
	CreateSkin();
	m_infoStr = _T("");
	m_info.SetWindowText(_T("00 / 100"));
	memset(m_fileName, 0, sizeof(m_fileName));
	m_index = 0;
	m_nPos = 0;
	m_tmpDirName = _T("");
	return TRUE;
}

DWORD  WINAPI CBurnDlg::WriteDVDVideoPro(LPVOID lpParam)
{
	CBurnDlg *pthis = (CBurnDlg *)lpParam;
	
	BOOL bRecompress = TRUE;
	UINT Format = 1;//1-NTSL 2-PAL
	UINT AspectRatio = 1;//1-4:3 2-16:9
	
	CBurnInterface::WriteDVDVideoEx("DVD", bRecompress, Format, AspectRatio, 
		pthis->m_index, &pthis->m_fileName[0][0]);
	
	pthis->KillTimer(1);
	CBurnInterface::Unload();
	pthis->OnCloseburndlg();
	return 0;
}

void CBurnDlg::OnTimer(UINT nIDEvent) 
{
	if (nIDEvent == 1)
	{
		m_nPos = CBurnInterface::WriteGetProgress();
		m_dvdBurnProgress.SetPos(m_nPos);
		
		unsigned char FileNamePtr[256] = {0};
		CBurnInterface::WriteGetCurrBurnFileName(FileNamePtr);
		CString tmpStr = _T("");
		tmpStr.Format("%s", FileNamePtr);
		GetDlgItem(IDC_STATIC_CURRBURNFILE)->SetWindowText(tmpStr);
		m_infoStr.Format("%02d / 100", m_nPos);
		m_info.SetWindowText(m_infoStr);
	}
	CDialog::OnTimer(nIDEvent);
}

void CBurnDlg::OnLoad() 
{
	CBurnInterface::Load();
}

void CBurnDlg::OnUnload() 
{
	CBurnInterface::Unload();
}

HBRUSH CBurnDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	pDC->SetBkMode(TRANSPARENT);
	return m_Brush;
	return hbr;
}

void CBurnDlg::CreateSkin()
{
	m_titleBar.Create(CRect(0,0,520,25),this,
		IDB_COMONTITLE,IDB_COMONTITLE,
		IDB_COMONTITLE,IDB_COMONTITLE);
	m_titleBar.SetLabel("Burning Files");

	m_btnClose.SetSkin(IDB_EXITNORMAL, IDB_EXITDOWN, IDB_EXITOVER, 0, 0, 0, 0, 0, 0);
	m_btnClose.SetTextColor(SYSTEM_BTNCOLOR);
	m_btnClose.SizeToContent();
}

void CBurnDlg::OnCloseburndlg()
{
	StopWrite();
	m_nPos = 0;
	CString tmpStr = _T("");
	for (int i = 0; i < m_index; i++)
	{
		tmpStr = _T("");
		tmpStr = &m_fileName[i][0];
		if(CConfigurationSingleton::instance()->m_util.getFileSuffix(tmpStr) == "peg")
		{
			SetFileAttributes(tmpStr.GetBuffer(0), FILE_ATTRIBUTE_NORMAL);
			DeleteFile(tmpStr.GetBuffer(0));
		}
	}
	CDialog::OnCancel();
}
