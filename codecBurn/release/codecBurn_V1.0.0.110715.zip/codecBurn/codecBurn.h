#if !defined(AFX_CODECBURN_H__E25ACA3C_49FC_45C9_BF84_3C6EC9102363__INCLUDED_)
#define AFX_CODECBURN_H__E25ACA3C_49FC_45C9_BF84_3C6EC9102363__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif
#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "vnplayer.h"
#include "resource.h"

class CCodecBurnApp : public CWinApp
{
public:
	CCodecBurnApp();

	public:
	virtual BOOL InitInstance();

	DECLARE_MESSAGE_MAP()
};

#endif