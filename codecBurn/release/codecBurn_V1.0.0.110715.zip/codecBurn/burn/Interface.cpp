#include "../stdafx.h"
#include "../codecBurn.h"
#include "Interface.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

HINSTANCE m_hBurnLibrary;

typedef int(_cdecl *FUN_SetDevice)(UCHAR);							 FUN_SetDevice fun_SetDevice;
typedef int(_cdecl *FUN_SetDriver)(PUCHAR);							 FUN_SetDriver fun_SetDriver;
typedef int(_cdecl *FUN_BlankDisc)();								 FUN_BlankDisc fun_BlankDisc;
typedef int(_cdecl *FUN_GetDiscInfo)(PBOOL,PBOOL,PINT);				 FUN_GetDiscInfo fun_GetDiscInfo;
typedef int(_cdecl *FUN_GetDiscInfoEx)(PBOOL,PBOOL,PINT,__int64*);	 FUN_GetDiscInfoEx fun_GetDiscInfoEx;
typedef int(_cdecl *FUN_SetCdSpeeds)(WORD, WORD);					 FUN_SetCdSpeeds fun_SetCdSpeeds;
typedef int(_cdecl *FUN_GetCdSpeeds)(PWORD,PWORD,PWORD,PWORD);		 FUN_GetCdSpeeds fun_GetCdSpeeds;
typedef int(_cdecl *FUN_Unload)(VOID);								 FUN_Unload fun_Unload;
typedef int(_cdecl *FUN_Load)(VOID);								 FUN_Load fun_Load;
typedef int(_cdecl *FUN_IsDeviceReady)(VOID);						 FUN_IsDeviceReady fun_IsDeviceReady;
typedef int(_cdecl *FUN_BurnProofControl)(BOOL);					 FUN_BurnProofControl fun_BurnProofControl;
typedef int(_cdecl *FUN_GetVendorProductStrings)(PUCHAR, PUCHAR);    FUN_GetVendorProductStrings fun_GetVendorProductStrings;
typedef int(_cdecl *FUN_GetSupportedWriteModes)(PBOOL,PBOOL,PBOOL);  FUN_GetSupportedWriteModes fun_GetSupportedWriteModes;
typedef int(_cdecl *FUN_AbortWrite)(VOID);							 FUN_AbortWrite fun_AbortWrite;
typedef int(_cdecl *FUN_AddFiles)(PCHAR,PCHAR,BOOL);				 FUN_AddFiles fun_AddFiles;
typedef int(_cdecl *FUN_AddFilesEx)(PCHAR,PCHAR,BOOL,PCHAR);		 FUN_AddFilesEx fun_AddFilesEx;
typedef int(_cdecl *FUN_DeleteFiles)(PCHAR,BOOL);					 FUN_DeleteFiles fun_DeleteFiles;
typedef int(_cdecl *FUN_ClearFiles)(VOID);							 FUN_ClearFiles fun_ClearFiles;
typedef int(_cdecl *FUN_WriteDataCD)(PCHAR,BOOL,BOOL);				 FUN_WriteDataCD fun_WriteDataCD;
typedef int(_cdecl *FUN_WriteDataCDEx)(PCHAR,BOOL,BOOL,BOOL,BOOL);	 FUN_WriteDataCDEx fun_WriteDataCDEx;
typedef int(_cdecl *FUN_WriteDataCDEx2)(PCHAR,PCHAR,BOOL,BOOL,BOOL,BOOL);	 FUN_WriteDataCDEx2 fun_WriteDataCDEx2;
typedef int(_cdecl *FUN_WriteUDFDataCD)(PCHAR,BOOL);				 FUN_WriteUDFDataCD fun_WriteUDFDataCD;
typedef int(_cdecl *FUN_WriteClose)(VOID);							 FUN_WriteClose fun_WriteClose;
typedef int(_cdecl *FUN_WriteImageToCD)(PCHAR,BOOL);				 FUN_WriteImageToCD fun_WriteImageToCD;
typedef int(_cdecl *FUN_WriteGetProgress)(VOID);					 FUN_WriteGetProgress fun_WriteGetProgress;
typedef int(_cdecl *FUN_WriteGetProgressEx)(PCHAR);					 FUN_WriteGetProgressEx fun_WriteGetProgressEx;
typedef int(_cdecl *FUN_WriteGetCurrBurnFileName)(PUCHAR);			 FUN_WriteGetCurrBurnFileName fun_WriteGetCurrBurnFileName;
typedef int(_cdecl *FUN_WriteGetCurrBurnFileNameEx)(PCHAR, PUCHAR);	 FUN_WriteGetCurrBurnFileNameEx fun_WriteGetCurrBurnFileNameEx;
typedef int(_cdecl *FUN_SetMessageHandle)(LONG, LONG);				 FUN_SetMessageHandle fun_SetMessageHandle;
typedef int(_cdecl *FUN_SetAutoRunDisc)(PCHAR, PCHAR);				 FUN_SetAutoRunDisc fun_SetAutoRunDisc;
typedef int(_cdecl *FUN_VerifyDisc)(PCHAR);							 FUN_VerifyDisc fun_VerifyDisc;

typedef int(_cdecl *FUN_SetImageFile)(PUCHAR);                       FUN_SetImageFile fun_SetImageFile;
typedef int(_cdecl *FUN_GetAudioFileInfo)(PUCHAR,PDWORD,PDWORD,PUCHAR);FUN_GetAudioFileInfo fun_GetAudioFileInfo;
typedef int(_cdecl *FUN_WriteAudioCD)(BOOL,PUCHAR);                  FUN_WriteAudioCD fun_WriteAudioCD;

typedef int(_cdecl *FUN_GetTrackInfo)(UCHAR,PUCHAR,PDISCTRACK_INFO); FUN_GetTrackInfo fun_GetTrackInfo;
typedef int(_cdecl *FUN_SaveAudioTrack)(UCHAR,UINT,PUCHAR);          FUN_SaveAudioTrack fun_SaveAudioTrack;
typedef int(_cdecl *FUN_CopyDisc)(UCHAR,UCHAR,PUCHAR);               FUN_CopyDisc fun_CopyDisc;
typedef int(_cdecl *FUN_CopyDiscGetProgress)(VOID);				     FUN_CopyDiscGetProgress fun_CopyDiscGetProgress;
typedef int(_cdecl *FUN_CopyStop)(VOID);				             FUN_CopyStop fun_CopyStop;

typedef int(_cdecl *FUN_WriteVideoCD)(PCHAR,UINT,PCHAR);			 FUN_WriteVideoCD fun_WriteVideoCD;
typedef int(_cdecl *FUN_WriteVideoCDEx)(PCHAR,BOOL,UINT,UINT,UINT,PCHAR); FUN_WriteVideoCDEx fun_WriteVideoCDEx;
typedef int(_cdecl *FUN_WriteSVCD)(PCHAR,BOOL,UINT,UINT,UINT,PCHAR); FUN_WriteSVCD fun_WriteSVCD;
typedef int(_cdecl *FUN_WriteDVDVideo)(PCHAR,UINT,PCHAR);			 FUN_WriteDVDVideo fun_WriteDVDVideo;
typedef int(_cdecl *FUN_WriteDVDVideoEx)(PCHAR,BOOL,UINT,UINT,UINT,PCHAR);FUN_WriteDVDVideoEx fun_WriteDVDVideoEx;

typedef int(_cdecl *FUN_RealTimeWrite_SetEstimateTotalWriteSize)(PCHAR,unsigned __int64);           FUN_RealTimeWrite_SetEstimateTotalWriteSize fun_RealTimeWrite_SetEstimateTotalWriteSize;
typedef int(_cdecl *FUN_RealTimeWrite_Begin)(PCHAR,PCHAR);           FUN_RealTimeWrite_Begin fun_RealTimeWrite_Begin;
typedef int(_cdecl *FUN_RealTimeWrite_CreateFile)(PCHAR,PCHAR);      FUN_RealTimeWrite_CreateFile fun_RealTimeWrite_CreateFile;
typedef int(_cdecl *FUN_RealTimeWrite_WriteFile)(PCHAR,PCHAR,INT);   FUN_RealTimeWrite_WriteFile fun_RealTimeWrite_WriteFile;
typedef int(_cdecl *FUN_RealTimeWrite_CloseFile)(PCHAR);             FUN_RealTimeWrite_CloseFile fun_RealTimeWrite_CloseFile;
typedef int(_cdecl *FUN_RealTimeWrite_End)(PCHAR);                   FUN_RealTimeWrite_End fun_RealTimeWrite_End;
typedef int(_cdecl *FUN_RealTimeWrite_GetDiscRemainCapacity)(PCHAR, __int64*);  FUN_RealTimeWrite_GetDiscRemainCapacity fun_RealTimeWrite_GetDiscRemainCapacity;

typedef int(_cdecl *FUN_RealTimeDVD_Begin)(PCHAR,PCHAR,PCHAR,BOOL,UINT,UINT);    FUN_RealTimeDVD_Begin fun_RealTimeDVD_Begin;
typedef int(_cdecl *FUN_RealTimeDVD_Write)(PCHAR,PCHAR,INT);         FUN_RealTimeDVD_Write fun_RealTimeDVD_Write;
typedef int(_cdecl *FUN_RealTimeDVD_End)(PCHAR);                     FUN_RealTimeDVD_End fun_RealTimeDVD_End;
typedef int(_cdecl *FUN_RealTimeDVD_GetDiscRemainCapacity)(PCHAR, __int64*);  FUN_RealTimeDVD_GetDiscRemainCapacity fun_RealTimeDVD_GetDiscRemainCapacity;


int CBurnInterface::LoadSDKDLL()
{
	//-----------------------Load Library------------------------
	m_hBurnLibrary = LoadLibrary("RecLib.dll");
	if (m_hBurnLibrary == NULL){
		AfxMessageBox("Load RecLib.dll failed!");
		return 0;
	}

	fun_SetDevice				= (FUN_SetDevice)GetProcAddress(m_hBurnLibrary,"Rec_SetDevice"); 										
	fun_SetDriver				= (FUN_SetDriver)GetProcAddress(m_hBurnLibrary,"Rec_SetDriver");
	fun_BlankDisc 				= (FUN_BlankDisc)GetProcAddress(m_hBurnLibrary,"Rec_EraseDisc"); 								
	fun_GetDiscInfo 			= (FUN_GetDiscInfo)GetProcAddress(m_hBurnLibrary,"Rec_GetDiscInfo"); 							
	fun_GetDiscInfoEx 			= (FUN_GetDiscInfoEx)GetProcAddress(m_hBurnLibrary,"Rec_GetDiscInfoEx");
	fun_SetCdSpeeds 			= (FUN_SetCdSpeeds)GetProcAddress(m_hBurnLibrary,"Rec_SetCdSpeeds"); 							
	fun_GetCdSpeeds 			= (FUN_GetCdSpeeds)GetProcAddress(m_hBurnLibrary,"Rec_GetCdSpeeds"); 							
	fun_Unload 					= (FUN_Unload)GetProcAddress(m_hBurnLibrary,"Rec_Unload"); 										
	fun_Load 					= (FUN_Load)GetProcAddress(m_hBurnLibrary,"Rec_Load"); 											
	fun_IsDeviceReady 			= (FUN_IsDeviceReady)GetProcAddress(m_hBurnLibrary,"Rec_IsDeviceReady"); 						
	fun_BurnProofControl 		= (FUN_BurnProofControl)GetProcAddress(m_hBurnLibrary,"Rec_BurnProofControl"); 					
	fun_GetVendorProductStrings = (FUN_GetVendorProductStrings)GetProcAddress(m_hBurnLibrary,"Rec_GetVendorProductStrings"); 	
	fun_GetSupportedWriteModes  = (FUN_GetSupportedWriteModes)GetProcAddress(m_hBurnLibrary,"Rec_GetSupportedWriteModes"); 		
	fun_AbortWrite 				= (FUN_AbortWrite)GetProcAddress(m_hBurnLibrary,"Rec_StopWrite"); 								
	fun_AddFiles 				= (FUN_AddFiles)GetProcAddress(m_hBurnLibrary,"Rec_AddFiles"); 									
	fun_AddFilesEx 				= (FUN_AddFilesEx)GetProcAddress(m_hBurnLibrary,"Rec_AddFilesEx"); 									
	fun_DeleteFiles 			= (FUN_DeleteFiles)GetProcAddress(m_hBurnLibrary,"Rec_DeleteFiles"); 							
	fun_ClearFiles   			= (FUN_ClearFiles)GetProcAddress(m_hBurnLibrary,"Rec_ClearFiles");	
	fun_WriteDataCD 			= (FUN_WriteDataCD)GetProcAddress(m_hBurnLibrary,"Rec_WriteDataCD"); 							
	fun_WriteDataCDEx 			= (FUN_WriteDataCDEx)GetProcAddress(m_hBurnLibrary,"Rec_WriteDataCDEx");
	fun_WriteDataCDEx2 			= (FUN_WriteDataCDEx2)GetProcAddress(m_hBurnLibrary,"Rec_WriteDataCDEx2");
	fun_WriteUDFDataCD 			= (FUN_WriteUDFDataCD)GetProcAddress(m_hBurnLibrary,"Rec_WriteUDFDataCD");
	fun_WriteClose 			    = (FUN_WriteClose)GetProcAddress(m_hBurnLibrary,"Rec_WriteClose"); 								
	fun_WriteImageToCD 		    = (FUN_WriteImageToCD)GetProcAddress(m_hBurnLibrary,"Rec_WriteImageToCD"); 						
	fun_WriteGetProgress 		= (FUN_WriteGetProgress)GetProcAddress(m_hBurnLibrary,"Rec_WriteGetProgress"); 					
	fun_WriteGetProgressEx 		= (FUN_WriteGetProgressEx)GetProcAddress(m_hBurnLibrary,"Rec_WriteGetProgressEx"); 					
	fun_SetMessageHandle        = (FUN_SetMessageHandle)GetProcAddress(m_hBurnLibrary,"Rec_SetMessageHandle");
	fun_WriteGetCurrBurnFileName= (FUN_WriteGetCurrBurnFileName)GetProcAddress(m_hBurnLibrary,"Rec_WriteGetCurrBurnFileName");
	fun_WriteGetCurrBurnFileNameEx= (FUN_WriteGetCurrBurnFileNameEx)GetProcAddress(m_hBurnLibrary,"Rec_WriteGetCurrBurnFileNameEx");
	fun_SetAutoRunDisc 		    = (FUN_SetAutoRunDisc)GetProcAddress(m_hBurnLibrary,"Rec_SetAutoRunDisc");
	fun_VerifyDisc		 		= (FUN_VerifyDisc)GetProcAddress(m_hBurnLibrary,"Rec_VerifyDisc");

	fun_SetImageFile            = (FUN_SetImageFile)GetProcAddress(m_hBurnLibrary,"Rec_SetImageFile");
	fun_GetAudioFileInfo        = (FUN_GetAudioFileInfo)GetProcAddress(m_hBurnLibrary,"Rec_GetAudioFileInfo");
	fun_WriteAudioCD            = (FUN_WriteAudioCD)GetProcAddress(m_hBurnLibrary,"Rec_WriteAudioCD");

	fun_GetTrackInfo            = (FUN_GetTrackInfo)GetProcAddress(m_hBurnLibrary,"Rec_GetTrackInfo");
	fun_SaveAudioTrack          = (FUN_SaveAudioTrack)GetProcAddress(m_hBurnLibrary,"Rec_SaveAudioTrack");
	fun_CopyDisc                = (FUN_CopyDisc)GetProcAddress(m_hBurnLibrary,"Rec_CopyDisc");
	fun_CopyDiscGetProgress     = (FUN_CopyDiscGetProgress)GetProcAddress(m_hBurnLibrary,"Rec_CopyDiscGetProgress");
	fun_CopyStop			    = (FUN_CopyStop)GetProcAddress(m_hBurnLibrary,"Rec_CopyDiscStop");
	fun_WriteVideoCD 			= (FUN_WriteVideoCD)GetProcAddress(m_hBurnLibrary,"Rec_WriteVideoCD");
	fun_WriteVideoCDEx 			= (FUN_WriteVideoCDEx)GetProcAddress(m_hBurnLibrary,"Rec_WriteVideoCDEx");
	fun_WriteSVCD    			= (FUN_WriteSVCD)GetProcAddress(m_hBurnLibrary,"Rec_WriteSVCD");
	fun_WriteDVDVideo 			= (FUN_WriteDVDVideo)GetProcAddress(m_hBurnLibrary,"Rec_WriteDVDVideo");
	fun_WriteDVDVideoEx			= (FUN_WriteDVDVideoEx)GetProcAddress(m_hBurnLibrary,"Rec_WriteDVDVideoEx");

	fun_RealTimeWrite_SetEstimateTotalWriteSize = (FUN_RealTimeWrite_SetEstimateTotalWriteSize)GetProcAddress(m_hBurnLibrary,"Rec_RealTimeWrite_SetEstimateTotalWriteSize");
	fun_RealTimeWrite_Begin     = (FUN_RealTimeWrite_Begin)GetProcAddress(m_hBurnLibrary,"Rec_RealTimeWrite_Begin");
	fun_RealTimeWrite_CreateFile= (FUN_RealTimeWrite_CreateFile)GetProcAddress(m_hBurnLibrary,"Rec_RealTimeWrite_CreateFile");
	fun_RealTimeWrite_WriteFile = (FUN_RealTimeWrite_WriteFile)GetProcAddress(m_hBurnLibrary,"Rec_RealTimeWrite_WriteFile");
	fun_RealTimeWrite_CloseFile = (FUN_RealTimeWrite_CloseFile)GetProcAddress(m_hBurnLibrary,"Rec_RealTimeWrite_CloseFile");
	fun_RealTimeWrite_End       = (FUN_RealTimeWrite_End)GetProcAddress(m_hBurnLibrary,"Rec_RealTimeWrite_End");
	fun_RealTimeWrite_GetDiscRemainCapacity       = (FUN_RealTimeWrite_GetDiscRemainCapacity)GetProcAddress(m_hBurnLibrary,"Rec_RealTimeWrite_GetDiscRemainCapacity");

	fun_RealTimeDVD_Begin       = (FUN_RealTimeDVD_Begin)GetProcAddress(m_hBurnLibrary,"Rec_RealTimeDVD_Begin");
	fun_RealTimeDVD_Write       = (FUN_RealTimeDVD_Write)GetProcAddress(m_hBurnLibrary,"Rec_RealTimeDVD_Write");
	fun_RealTimeDVD_End         = (FUN_RealTimeDVD_End)GetProcAddress(m_hBurnLibrary,"Rec_RealTimeDVD_End");
	fun_RealTimeDVD_GetDiscRemainCapacity         = (FUN_RealTimeDVD_GetDiscRemainCapacity)GetProcAddress(m_hBurnLibrary,"Rec_RealTimeDVD_GetDiscRemainCapacity");

	ASSERT(fun_SetDevice);
	ASSERT(fun_SetDriver);
	ASSERT(fun_BlankDisc);
	ASSERT(fun_GetDiscInfo);
	ASSERT(fun_GetDiscInfoEx);
	ASSERT(fun_SetCdSpeeds);
	ASSERT(fun_GetCdSpeeds);
	ASSERT(fun_Unload);
	ASSERT(fun_Load);
	ASSERT(fun_IsDeviceReady);
	ASSERT(fun_BurnProofControl);
	ASSERT(fun_GetVendorProductStrings);
	ASSERT(fun_GetSupportedWriteModes);
	ASSERT(fun_AbortWrite);
	ASSERT(fun_AddFiles);
	ASSERT(fun_AddFilesEx);
	ASSERT(fun_DeleteFiles);
	ASSERT(fun_ClearFiles);
	ASSERT(fun_WriteDataCD);
	ASSERT(fun_WriteDataCDEx);
	ASSERT(fun_WriteDataCDEx2);
	ASSERT(fun_WriteUDFDataCD);
	ASSERT(fun_WriteClose);
	ASSERT(fun_WriteImageToCD);
	ASSERT(fun_WriteGetProgress);
	ASSERT(fun_WriteGetProgressEx);
	ASSERT(fun_SetMessageHandle);
	ASSERT(fun_WriteGetCurrBurnFileName);
	ASSERT(fun_WriteGetCurrBurnFileNameEx);
	ASSERT(fun_SetAutoRunDisc);
	ASSERT(fun_VerifyDisc);

#ifdef _VER_PRO
	ASSERT(fun_SetImageFile);
	ASSERT(fun_GetAudioFileInfo);
	ASSERT(fun_WriteAudioCD);
#endif

#ifdef _VER_ADV
	ASSERT(fun_GetTrackInfo);
	ASSERT(fun_SaveAudioTrack);
	ASSERT(fun_CopyDisc);
	ASSERT(fun_CopyDiscGetProgress);
	ASSERT(fun_CopyStop);
	ASSERT(fun_WriteVideoCD);
	ASSERT(fun_WriteVideoCDEx);
	ASSERT(fun_WriteSVCD);
	ASSERT(fun_WriteDVDVideo);
	ASSERT(fun_WriteDVDVideoEx);
#endif

	ASSERT(fun_RealTimeWrite_SetEstimateTotalWriteSize);
	ASSERT(fun_RealTimeWrite_Begin);
	ASSERT(fun_RealTimeWrite_CreateFile);
	ASSERT(fun_RealTimeWrite_WriteFile);
	ASSERT(fun_RealTimeWrite_CloseFile);
	ASSERT(fun_RealTimeWrite_End);
	ASSERT(fun_RealTimeWrite_GetDiscRemainCapacity);
	//-----------------------Load Library------------------------
	return 1;
}

CBurnInterface::CBurnInterface()
{
	
}

CBurnInterface::~CBurnInterface()
{
	FreeLibrary(m_hBurnLibrary);
}

CString CBurnInterface::GetResultInfo(int ret)
{
	CString ss;
	switch (ret)
	{
	case 1: ss = "Success"; 	break;
	case 0: ss = "Failed"; 	break;
	case -5: ss = "Send Operation Command Failed"; 	break;
	case -6: ss = "Send Burn Command Failed"; 	break;
	case -7: ss = "Error Command Request"; 	break;
	case -8: ss = "Error CD-ROM Driver Number"; 	break;
	case -10: ss = "Error Operation Command"; 	break;
	case -15: ss = "Device busy or not ready"; 	break;
	case -44: ss = "Blank Disk Examine Error"; 	break;
	case -50: ss = "This Disk is Blank Disk"; 	break;	
	case -100: ss = "User Terminate Burning"; 	break;
	case -109: ss = "Create File Failed"; 	break;
	case -113: ss = "Write Disk Error"; 	break;
	case -124: ss = "Data Exceed Disk Capability"; 	break;
	case -144: ss = "Error Channel Type"; 	break;
	case -156: ss = "Can not recognize this type of mirror image"; 	break;
	case -157: ss = "Can not burn to DVD"; 	break;
	case -158: ss = "Not enough space on target disk"; 	break;
	case -159: ss = "Do not have enough space on hard disk to save temp files"; 	break;
	case -160: ss = "Error when copy temp file"; 	break;
	case -161: ss = "Can not file temp file when copy"; 	break;
	case -162: ss = "File type error when copy"; 	break;
	case -301: ss = "Can not write on this disk"; 	break;
	case -304: ss = "Read disk error"; 	break;
	case -305: ss = "Read channel information error"; 	break;
	case -510: ss = "Decode music file error"; 	break;
	case -511: ss = "Disk error when prepare write to disk"; 	break;
	case -512: ss = "File to big"; 	break;
	case -601: ss = "Init covert file error"; 	break;
	case -602: ss = "Convert file error"; 	break;
	case -603: ss = "Converting file error"; 	break;
	default: 
		ss.Format("Error code: %d", ret);
	}
	return ss;
}

int CBurnInterface::ShowResult(int ret)
{
	CString tmpStr = GetResultInfo(ret);
	AfxMessageBox(tmpStr);
	return ret;
}

int CBurnInterface::SetDevice(UCHAR DeviceId)
{
	return fun_SetDevice(DeviceId);
}

int CBurnInterface::SetDriver(PUCHAR DriverName)
{
	return fun_SetDriver(DriverName);
}

int CBurnInterface::BlankDisc()
{
	//return ShowResult(fun_BlankDisc());
	int iRet = fun_BlankDisc();
	if (iRet == 1)
	{
		return iRet;
	} 
	else
	{
		return ShowResult(iRet);
	}
}

int CBurnInterface::GetDiscInfoEx(PBOOL pBOOL_IsDiscBlank, PBOOL pBOOL_IsDiscWriteable, PINT pINT_DiscType, __int64 *pDiscRemainCapability)
{
	return fun_GetDiscInfoEx(pBOOL_IsDiscBlank, pBOOL_IsDiscWriteable, pINT_DiscType, pDiscRemainCapability);
}

int CBurnInterface::SetCdSpeeds(WORD WORD_ReadSpeed, WORD WORD_WriteSpeed)
{
	return ShowResult(fun_SetCdSpeeds(0,0));
}

int CBurnInterface::GetCdSpeeds(PWORD pCurrentReadSpeed, PWORD pCurrentWriteSpeed, PWORD pMaximumReadSpeed, PWORD pMaximumWriteSpeed)
{
	return ShowResult(fun_GetCdSpeeds(pCurrentReadSpeed, pCurrentWriteSpeed, pMaximumReadSpeed, pMaximumWriteSpeed));
}

int CBurnInterface::Unload()
{
	return fun_Unload();
}

int CBurnInterface::Load()
{
	return fun_Load();
}

int CBurnInterface::IsDeviceReady()
{
	return ShowResult(fun_IsDeviceReady());
}

int CBurnInterface::BurnProofControl(BOOL p__BOOL__EnableBurnProof)
{
	return ShowResult(fun_BurnProofControl(p__BOOL__EnableBurnProof));
}

int CBurnInterface::GetVendorProductStrings(PUCHAR p__PUCHAR__VendorNamePtr, PUCHAR p__PUCHAR__ProductNamePtr)
{
	return fun_GetVendorProductStrings(p__PUCHAR__VendorNamePtr, p__PUCHAR__ProductNamePtr);
}

int CBurnInterface::GetSupportedWriteModes(PBOOL p__PBOOL__IsTaoSupported, PBOOL p__PBOOL__IsDaoSupported, PBOOL p__PBOOL__IsSaoSupported)
{
	return fun_GetSupportedWriteModes(p__PBOOL__IsTaoSupported, p__PBOOL__IsDaoSupported, p__PBOOL__IsSaoSupported);
}

int CBurnInterface::AbortWrite()
{
	return fun_AbortWrite();
}

int CBurnInterface::AddFiles(PCHAR pSourName, PCHAR pTarParentFolder, BOOL BOOL_isMp3CD)
{
	return fun_AddFiles(pSourName, pTarParentFolder, BOOL_isMp3CD);
}

int CBurnInterface::AddFilesEx(PCHAR pSourName, PCHAR pTarParentFolder, BOOL BOOL_isMp3CD, PCHAR pTarFileName)
{
	return fun_AddFilesEx(pSourName, pTarParentFolder, BOOL_isMp3CD, pTarFileName);
}

int CBurnInterface::DeleteFiles(PCHAR pTargetName, BOOL BOOL_isFolder)
{
	return fun_DeleteFiles(pTargetName, BOOL_isFolder);
}

int CBurnInterface::ClearFiles()
{
	return fun_ClearFiles();
}

int CBurnInterface::WriteDataCD(PCHAR VolumeName, BOOL BOOL_IsMp3CD, BOOL BOOL_IsTestWrite)
{
	return ShowResult(fun_WriteDataCD(VolumeName, BOOL_IsMp3CD, BOOL_IsTestWrite));
}

int CBurnInterface::WriteDataCDEx(PCHAR VolumeName, BOOL BOOL_IsMp3CD, BOOL BOOL_IsTestWrite, BOOL BOOL_IsMultiSession, BOOL BOOL_IsEjectDiscAfterRecord)
{
	return fun_WriteDataCDEx(VolumeName, BOOL_IsMp3CD, BOOL_IsTestWrite, BOOL_IsMultiSession, BOOL_IsEjectDiscAfterRecord);
}

int CBurnInterface::WriteDataCDEx2(PCHAR DriverName, PCHAR VolumeName, BOOL BOOL_IsMp3CD, BOOL BOOL_IsTestWrite, BOOL BOOL_IsMultiSession, BOOL BOOL_IsEjectDiscAfterRecord)
{
	return fun_WriteDataCDEx2(DriverName, VolumeName, BOOL_IsMp3CD, BOOL_IsTestWrite, BOOL_IsMultiSession, BOOL_IsEjectDiscAfterRecord);
}

int CBurnInterface::WriteUDFDataCD(PCHAR VolumeName,BOOL BOOL_IsTestWrite)
{
	return ShowResult(fun_WriteUDFDataCD(VolumeName, BOOL_IsTestWrite));
}

int CBurnInterface::WriteClose()
{
	return fun_WriteClose();
}

int CBurnInterface::WriteImageToCD(PCHAR pCHAR_ImageFileName, BOOL BOOL_IsTestWrite)
{
	return ShowResult(fun_WriteImageToCD(pCHAR_ImageFileName, BOOL_IsTestWrite));
}

int CBurnInterface::WriteGetProgress()
{
	return fun_WriteGetProgress();
}

int CBurnInterface::WriteGetProgressEx(PCHAR DriverName)
{
	return fun_WriteGetProgressEx(DriverName);
}

int CBurnInterface::WriteGetCurrBurnFileName(PUCHAR p__PUCHAR__CurrBurnFile)
{
	return fun_WriteGetCurrBurnFileName(p__PUCHAR__CurrBurnFile);
}

int CBurnInterface::WriteGetCurrBurnFileNameEx(PCHAR DriverName, PUCHAR p__PUCHAR__CurrBurnFile)
{
	return fun_WriteGetCurrBurnFileNameEx(DriverName, p__PUCHAR__CurrBurnFile);
}

int CBurnInterface::SetMessageHandle(long CallWndHandle, long MsgNum)
{
	return fun_SetMessageHandle(CallWndHandle, MsgNum);
}

int CBurnInterface::SetImageFile(PUCHAR ImageFileName)
{
	return fun_SetImageFile(ImageFileName);
}

int CBurnInterface::GetAudioFileInfo(PUCHAR pFileName, PDWORD pWORD_TrackLength, PDWORD pWORD_SectorLength, PUCHAR PCHAR_TimeLength)
{
	return ShowResult(fun_GetAudioFileInfo(pFileName, pWORD_TrackLength, pWORD_SectorLength, PCHAR_TimeLength));
}

int CBurnInterface::WriteAudioCD(BOOL BOOL_IsTestWrite, UCHAR AudioTrackFileNames[][MAX_PATH])
{
	return ShowResult(fun_WriteAudioCD(BOOL_IsTestWrite, &AudioTrackFileNames[0][0]));
}

int CBurnInterface::GetTrackInfo(UCHAR DeviceId, PUCHAR ImageFileName, DISCTRACK_INFO track_info[])
{
	return fun_GetTrackInfo(DeviceId, ImageFileName, track_info);
}

int CBurnInterface::SaveAudioTrack(UCHAR DeviceId, UINT TrackIndex, PUCHAR SaveFileName)
{
	return ShowResult(fun_SaveAudioTrack(DeviceId, TrackIndex, SaveFileName));
}

int CBurnInterface::CopyDisc(UCHAR SourceDeviceId, UCHAR TargetDeviceId, PUCHAR CopyTempFile)
{
	return ShowResult(fun_CopyDisc(SourceDeviceId, TargetDeviceId, CopyTempFile));
}

int CBurnInterface::CopyDiscGetProgress()
{
	return fun_CopyDiscGetProgress();
}

int CBurnInterface::CopyStop()
{
	return fun_CopyStop();
}

int CBurnInterface::WriteVideoCD(PCHAR VolumeName, UINT VCDSourceMpegFileNumber, PCHAR VCDSourceMpegFileNames)
{
	return ShowResult(fun_WriteVideoCD(VolumeName, VCDSourceMpegFileNumber, VCDSourceMpegFileNames));
}

int CBurnInterface::WriteVideoCDEx(PCHAR VolumeName, 
							   BOOL bRecompress,
							   UINT Format,
							   UINT AspectRatio,
							   UINT VCDSourceMpegFileNumber, PCHAR VCDSourceMpegFileNames)
{
	return ShowResult(fun_WriteVideoCDEx(VolumeName, bRecompress, Format, AspectRatio, VCDSourceMpegFileNumber, VCDSourceMpegFileNames));
}

int CBurnInterface::WriteSVCD(PCHAR VolumeName, 
							   BOOL bRecompress,
							   UINT Format,
							   UINT AspectRatio,
							   UINT VCDSourceMpegFileNumber, PCHAR VCDSourceMpegFileNames)
{
	return ShowResult(fun_WriteSVCD(VolumeName, bRecompress, Format, AspectRatio, VCDSourceMpegFileNumber, VCDSourceMpegFileNames));
}

int CBurnInterface::WriteDVDVideo(PCHAR VolumeName,UINT  DVDSourceMpegFileNumber,PCHAR DVDSourceMpegFileNames)
{
	return ShowResult(fun_WriteDVDVideo(VolumeName, DVDSourceMpegFileNumber, DVDSourceMpegFileNames));
}

int CBurnInterface::WriteDVDVideoEx(PCHAR VolumeName,
		                       BOOL bRecompress,
							   UINT Format,
							   UINT AspectRatio,
		                       UINT DVDSourceMpegFileNumber,
							   PCHAR DVDSourceMpegFileNames)
{
	int nRet = fun_WriteDVDVideoEx(VolumeName, bRecompress, Format, AspectRatio,DVDSourceMpegFileNumber, DVDSourceMpegFileNames);
	if (nRet == 1)
	{
		AfxMessageBox("Successfully Burned DVD");
	}
	else
	{
		ShowResult(nRet);
	}
	return nRet;
}

BOOL CBurnInterface::JudgeDisc()
{
	if(fun_IsDeviceReady() != 1)
	{
		AfxMessageBox("CD-ROM busy or disk are not ready, Please try later!");
		return FALSE;
	}

	BOOL IsDiscBlank = FALSE;
	BOOL IsDiscWriteable = FALSE;
	INT  DiscType = 0;	
	__int64 DiscRemainCapability = 0; 

	if(fun_GetDiscInfoEx(&IsDiscBlank, &IsDiscWriteable, &DiscType, &DiscRemainCapability) != 1){
		AfxMessageBox("Disk information error, Please try again!");
		return FALSE;
	}

	if((IsDiscWriteable) && (DiscRemainCapability > 0))
	{}
	else{
		AfxMessageBox("Can not burn this disk, Please try again!");
		return FALSE;
	}

	return TRUE;
}

int CBurnInterface::SetAutoRunDisc(PCHAR pAutoRunExeFileNameOfDisc, PCHAR pAutoRunIconFileNameOfDisc)
{
	return fun_SetAutoRunDisc(pAutoRunExeFileNameOfDisc, pAutoRunIconFileNameOfDisc);
}

int CBurnInterface::VerifyDisc(PCHAR DriverName)
{
	return fun_VerifyDisc(DriverName);
}

int CBurnInterface::RealTimeWrite_SetEstimateTotalWriteSize(PCHAR DriverName, unsigned __int64 Size)
{
	return fun_RealTimeWrite_SetEstimateTotalWriteSize(DriverName, Size);
}

int CBurnInterface::RealTimeWrite_Begin(PCHAR DriverName, PCHAR VolumeName)
{
	return fun_RealTimeWrite_Begin(DriverName, VolumeName);
}

int CBurnInterface::RealTimeWrite_CreateFile(PCHAR DriverName, PCHAR FilePathName)
{
	return fun_RealTimeWrite_CreateFile(DriverName, FilePathName);
}

int CBurnInterface::RealTimeWrite_WriteFile(PCHAR DriverName, PCHAR pBuf, INT BufSize)
{
	return fun_RealTimeWrite_WriteFile(DriverName, pBuf, BufSize);
}

int CBurnInterface::RealTimeWrite_CloseFile(PCHAR DriverName)
{
	return fun_RealTimeWrite_CloseFile(DriverName);
}

int CBurnInterface::RealTimeWrite_End(PCHAR DriverName)
{
	return fun_RealTimeWrite_End(DriverName);
}

int CBurnInterface::RealTimeWrite_GetDiscRemainCapacity(PCHAR DriverName, __int64 *pDiscRemainCapability)
{
	return fun_RealTimeWrite_GetDiscRemainCapacity(DriverName, pDiscRemainCapability);
}

int CBurnInterface::RealTimeDVD_Begin(PCHAR DriverName, PCHAR VolumeName, 
								PCHAR sVideoType, 
								BOOL  bRecompress,
								UINT  Format,
								UINT  AspectRatio)
{
	return fun_RealTimeDVD_Begin(DriverName, VolumeName, sVideoType, bRecompress, Format, AspectRatio);
}

int CBurnInterface::RealTimeDVD_Write(PCHAR DriverName, PCHAR pBuf, INT BufSize)
{
	return fun_RealTimeDVD_Write(DriverName, pBuf, BufSize);
}

int CBurnInterface::RealTimeDVD_End(PCHAR DriverName)
{
	return fun_RealTimeDVD_End(DriverName);
}

int CBurnInterface::RealTimeDVD_GetDiscRemainCapacity(PCHAR DriverName, __int64 *pDiscRemainCapability)
{
	return fun_RealTimeDVD_GetDiscRemainCapacity(DriverName, pDiscRemainCapability);
}
