#if !defined(__INTERFACE_H__)
#define __INTERFACE_H__

#if _MSC_VER > 1000
#pragma once
#endif

#define _VER_COMMON
#define _VER_PRO
#define _VER_ADV

typedef struct _DISCTRACK_INFO
{
	BOOL  bAudioTrack;
	ULONG ulongStartSector;
    ULONG ulongEndSector;
}DISCTRACK_INFO;
typedef DISCTRACK_INFO* PDISCTRACK_INFO;

class CBurnInterface
{
public:	
	static BOOL JudgeDisc();
    //_VER_ADV
	static int WriteVideoCD(PCHAR VolumeName,UINT  VCDSourceMpegFileNumber,PCHAR VCDSourceMpegFileNames);
	static int WriteVideoCDEx(PCHAR VolumeName, 
							   BOOL bRecompress,
							   UINT Format,
							   UINT AspectRatio,
							   UINT VCDSourceMpegFileNumber, PCHAR VCDSourceMpegFileNames);
	static int WriteSVCD(PCHAR VolumeName, 
							   BOOL bRecompress,
							   UINT Format,
							   UINT AspectRatio,
							   UINT VCDSourceMpegFileNumber, PCHAR VCDSourceMpegFileNames);
	static int WriteDVDVideo(PCHAR VolumeName,UINT  DVDSourceMpegFileNumber,PCHAR DVDSourceMpegFileNames);
	static int WriteDVDVideoEx(PCHAR VolumeName,
		                       BOOL bRecompress,
							   UINT Format,
							   UINT AspectRatio,
		                       UINT DVDSourceMpegFileNumber,
							   PCHAR DVDSourceMpegFileNames);
	static int CopyStop();
	static int CopyDiscGetProgress();
	static int CopyDisc(UCHAR SourceDeviceId,UCHAR TargetDeviceId,PUCHAR CopyTempFile);
	static int SaveAudioTrack(UCHAR DeviceId,UINT  TrackIndex,PUCHAR SaveFileName);
	static int GetTrackInfo(UCHAR DeviceId, PUCHAR ImageFileName,DISCTRACK_INFO track_info[MAX_TRACKS]);
	static int WriteDataCDEx2(PCHAR DriverName, PCHAR VolumeName,BOOL BOOL_IsMp3CD,BOOL BOOL_IsTestWrite,BOOL BOOL_IsMultiSession ,BOOL BOOL_IsEjectDiscAfterRecord);
	static int WriteGetProgressEx(PCHAR DriverName);
	static int WriteGetCurrBurnFileNameEx(PCHAR DriverName, PUCHAR p__PUCHAR__CurrBurnFile);

    // _VER_PRO
	static int WriteAudioCD(BOOL BOOL_IsTestWrite,UCHAR AudioTrackFileNames[MAX_TRACKS][MAX_PATH]);
	static int GetAudioFileInfo(PUCHAR pFileName,PDWORD pWORD_TrackLength,PDWORD pWORD_SectorLength,PUCHAR PCHAR_TimeLength);
	static int SetImageFile(PUCHAR ImageFileName);

	//_VER_COMMON
	static int SetMessageHandle(long CallWndHandle, long MsgNum);
	static int WriteGetCurrBurnFileName(PUCHAR p__PUCHAR__CurrBurnFile);
	static int WriteGetProgress();
	static int WriteImageToCD(PCHAR pCHAR_ImageFileName,BOOL BOOL_IsTestWrite);
	static int WriteClose();
	static int WriteDataCDEx(PCHAR VolumeName,BOOL BOOL_IsMp3CD,BOOL BOOL_IsTestWrite,BOOL BOOL_IsMultiSession ,BOOL BOOL_IsEjectDiscAfterRecord);	
	static int WriteDataCD(PCHAR VolumeName,BOOL BOOL_IsMp3CD,BOOL BOOL_IsTestWrite);
	static int WriteUDFDataCD(PCHAR VolumeName,BOOL BOOL_IsTestWrite);
	static int ClearFiles();
	static int DeleteFiles(PCHAR pTargetName,BOOL  BOOL_isFolder);
	static int AddFiles(PCHAR pSourName, PCHAR pTarParentFolder, BOOL  BOOL_isMp3CD);
	static int AddFilesEx(PCHAR pSourName, PCHAR pTarParentFolder, BOOL  BOOL_isMp3CD, PCHAR pTarFileName);
	static int AbortWrite();
	static int GetSupportedWriteModes(PBOOL p__PBOOL__IsTaoSupported,PBOOL p__PBOOL__IsDaoSupported,PBOOL p__PBOOL__IsSaoSupported);
	static int GetVendorProductStrings(PUCHAR p__PUCHAR__VendorNamePtr, PUCHAR p__PUCHAR__ProductNamePtr);
	static int BurnProofControl(BOOL p__BOOL__EnableBurnProof);
	static int IsDeviceReady();
	static int Load();
	static int Unload();
	static int GetCdSpeeds(PWORD pWORD_CurrentReadSpeed,PWORD pWORD_CurrentWriteSpeed,PWORD pWORD_MaximumReadSpeed,PWORD pWORD_MaximumWriteSpeed);
	static int SetCdSpeeds(WORD WORD_ReadSpeed,WORD WORD_WriteSpeed);
	static int GetDiscInfoEx(PBOOL pBOOL_IsDiscBlank, PBOOL pBOOL_IsDiscWriteable, PINT  pINT_DiscType, __int64 *pDiscRemainCapability);
	static int BlankDisc();
	static int SetDevice(UCHAR DeviceId);
	static int SetDriver(PUCHAR DriverName);
	static int SetAutoRunDisc(PCHAR pAutoRunExeFileNameOfDisc, PCHAR pAutoRunIconFileNameOfDisc);
	static int VerifyDisc(PCHAR DriverName);

	//_VER_REALTIME
	static int RealTimeWrite_SetEstimateTotalWriteSize(PCHAR DriverName, unsigned __int64 Size);
	static int RealTimeWrite_Begin(PCHAR DriverName, PCHAR VolumeName);
	static int RealTimeWrite_CreateFile(PCHAR DriverName, PCHAR FilePathName);
	static int RealTimeWrite_WriteFile(PCHAR DriverName, PCHAR pBuf, INT BufSize);
	static int RealTimeWrite_CloseFile(PCHAR DriverName);
	static int RealTimeWrite_End(PCHAR DriverName);
	static int RealTimeWrite_GetDiscRemainCapacity(PCHAR DriverName, __int64 *pDiscRemainCapability);

	static int RealTimeDVD_Begin(PCHAR DriverName, PCHAR VolumeName, 
								PCHAR sVideoType, 
								BOOL  bRecompress,
								UINT  Format,
								UINT  AspectRatio);
	static int RealTimeDVD_Write(PCHAR DriverName, PCHAR pBuf, INT BufSize);
	static int RealTimeDVD_End(PCHAR DriverName);
	static int RealTimeDVD_GetDiscRemainCapacity(PCHAR DriverName, __int64 *pDiscRemainCapability);

	static int LoadSDKDLL();

	static CString GetResultInfo(int ret);
	
	CBurnInterface();
	virtual ~CBurnInterface();

	static int ShowResult(int ret);	
private:	
};
#endif // !defined(__INTERFACE_H__)
